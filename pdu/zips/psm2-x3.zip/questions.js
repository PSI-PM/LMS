var META = {"minutes": 90, "pass_mark": 85, "pass_count": 26};
var QUESTIONS = [
 {
  "n": 1,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Empiricism · Scrum Values",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "At a genome sequencing lab, the Developers have started rounding their Daily Scrum updates so that work always appears on track. The Scrum Master learns that the Product Owner has, in the past two Sprints, publicly criticised individuals whose items slipped.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Remind the Developers that Openness is a Scrum Value and that accurate updates are their responsibility.",
   "Address what happens when work slips, with the Product Owner, so that reporting a problem stops being personally costly.",
   "Ask the Product Owner not to attend the Daily Scrum so the Developers can speak freely.",
   "Introduce a written status format so progress is recorded factually rather than described aloud."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Asks the Developers to absorb a personal cost so the framework works. They already know their updates are inaccurate; they are rounding for a reason that is rational given what happened to the last person who did not.",
   "Correct. Transparency is a precondition produced by the environment, not a quality demanded of individuals. The durable fix is to change what reporting a slip costs, which is a conversation with the person creating the cost.",
   "Removes the Product Owner from an event the whole Scrum Team may attend, and hides from her exactly the information she most needs to see. It treats the symptom by concealing it.",
   "A format change addressed to a fear problem. People who round spoken updates will round written ones, because the risk they are managing is unchanged."
  ],
  "hard": "A cites a real value and D looks like a transparency mechanism. Both leave intact the reason the Developers are rounding."
 },
 {
  "n": 2,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Sprint Planning · Events",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "At a toll road authority, Sprint Planning routinely overruns because the Developers spend most of it clarifying what items mean and breaking them down. The Product Backlog is ordered and the Product Goal is clear, but items arrive at Sprint Planning large and vague.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Split Sprint Planning into two sessions on consecutive days.",
   "Ask the Product Owner to write more detailed specifications for each item.",
   "Help the Scrum Team establish ongoing refinement, so items are understood and sized before Sprint Planning.",
   "Extend the Sprint Planning timebox so the clarification has room to happen."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Two sittings of the same misused event. The clarification is still happening in Sprint Planning; it now occupies two days instead of one.",
   "Refinement is the collaborative work of the Scrum Team, not a specification the Product Owner writes alone. It also risks detailed specifications for work that changes before it is built.",
   "Correct. The cause is upstream: refinement is an ongoing activity that adds detail, order, and size to items before they reach Sprint Planning. Establishing it is what makes Sprint Planning about planning again.",
   "Gives the problem more room rather than removing it. Sprint Planning is overrunning because upstream work is not happening; a longer timebox absorbs the refinement into the wrong event."
  ],
  "hard": "D and A both look like reasonable accommodations of a real time pressure, and both treat Sprint Planning as the place to fix a problem that originates before it."
 },
 {
  "n": 3,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Scrum Team · Developers",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "A satellite ground-station team includes a specialist whose skills nobody else has. When she is on leave, all work touching her area stops. The other Developers treat her area as off-limits, and she prefers it that way because she is confident the work will be done correctly.",
  "ask": "Which of the following are true of this situation? Select all that apply.",
  "options": [
   "The single-person dependency is an impediment to reliably producing a Done Increment.",
   "Reducing the dependency does not require every Developer to match her depth of skill.",
   "A Scrum Team may contain specialists.",
   "The arrangement is acceptable as long as the specialist's work is high quality."
  ],
  "correct": [
   0,
   1,
   2
  ],
  "rationale": [
   "Correct. A specialism that halts all work in an area when one person is away has become a permanent boundary, which is an impediment to the team reliably delivering a Done Increment.",
   "Correct. Cross-functionality is a direction, not a demand that everyone reach her depth — only that enough knowledge is spread that her absence no longer stops the work.",
   "Correct. A Scrum Team may contain specialists; cross-functionality is a property of the team as a whole, not a requirement that everyone can do everything.",
   "Incorrect. Quality is not the issue. However good her work, an area that stops entirely in her absence is a single point of failure the team must reduce over time."
  ],
  "hard": "D is the tempting distractor because the specialist's work genuinely is good. Quality is not what makes the boundary an impediment; the single point of failure is."
 },
 {
  "n": 4,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Events · The Sprint",
  "shape": "Hold a line",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "If the Developers complete all the items they forecast well before the Sprint ends, the Sprint should be closed early and the next one started.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. The Sprint is a fixed-length container, and a new Sprint starts immediately after the previous one concludes at its planned end — not when a forecast happens to be exhausted. Finishing the forecast early does not mean the Sprint's work is done: the Developers collaborate with the Product Owner on what else advances the Sprint Goal and the Product Goal, refine upcoming work, or improve the product and their practices. Only the Product Owner may end a Sprint early, and only by cancelling it because the Sprint Goal has become obsolete — which is a different situation entirely from having capacity left."
  ],
  "hard": "The statement rewards a candidate's intuition that idle capacity is waste, and conflates completing a forecast with completing the Sprint."
 },
 {
  "n": 5,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Done · Artifacts",
  "shape": "Hold a line",
  "type": "multi",
  "stem": "A team at a clearinghouse works to an organisational Definition of Done. For an upcoming release, the Developers propose adding a penetration-test clause that applies only to their product.",
  "ask": "Which of the following are true? Select all that apply.",
  "options": [
   "The organisational standard is a minimum that all teams must meet.",
   "A Scrum Team may apply a Definition of Done more stringent than the organisational standard.",
   "Work that does not meet the Definition of Done is not released as part of the Increment.",
   "A team may relax a clause of the organisational standard if its Product Owner agrees the trade-off."
  ],
  "correct": [
   0,
   1,
   2
  ],
  "rationale": [
   "Correct. Where the organisation has a standard, all Scrum Teams must follow it as a minimum.",
   "Correct. Teams may be stricter than an organisational standard, and adding a product-specific clause is exactly that.",
   "Correct. Work failing the Definition of Done is not part of the Increment and is not released as though it were.",
   "Incorrect. The direction rule runs one way only. A team may add to the standard; it may never fall below it, and the Product Owner has no authority to waive an organisational quality requirement."
  ],
  "hard": "D inverts the direction rule and attaches a plausible authority to it. The Product Owner's genuine accountability for value is the bait."
 },
 {
  "n": 6,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Empiricism",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A new Scrum Team at a title insurer asks the Scrum Master why they must produce a usable Increment every Sprint when the full product will not be released for a year. They argue that integrating and polishing every Sprint is wasted effort until launch.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Explain that a usable Increment each Sprint is what makes inspection and adaptation possible, and that deferring integration hides risk until it is expensive to address.",
   "Agree to relax the requirement until closer to launch, then reinstate it.",
   "Ask the Product Owner to decide, since the release timing is a product decision.",
   "Use open questions to let the team reach its own conclusion about why Increments matter."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. This is a knowledge gap with a settled answer, so the stance is teaching. A usable Increment is what there is to inspect; without one, the team learns nothing until integration, by which point being wrong is expensive. The year-long horizon is the reason to inspect often, not a reason to defer.",
   "Concedes the framework to avoid a conversation, and stores up exactly the integration risk the requirement exists to surface early.",
   "The release date is the Product Owner's; whether Scrum requires a usable Increment is not a matter she decides. It is defined, and deferring to her misplaces the question.",
   "Coaching a team that lacks the underlying knowledge. They are not short of the capacity to reason about empiricism; they are short of understanding what the Increment is for."
  ],
  "hard": "D is the reflexive stance for an experienced Scrum Master and is wrong here for the same reason it is often wrong: the gap is knowledge, and coaching withholds the answer the team needs."
 },
 {
  "n": 7,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "A Scrum Master at a legal-tech firm has drifted into deciding technical approaches when the Developers disagree, because she used to be an engineer and her calls are usually sound. The Developers now bring most technical disputes to her rather than resolving them.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Ask the most senior Developer to arbitrate technical disputes instead.",
   "Decide only the disputes that put the Sprint Goal at risk, and let the Developers handle the rest.",
   "Continue; her technical judgement is good and disputes are resolved quickly.",
   "Stop deciding technical disputes, explain why, and help the Developers build the means to resolve them themselves."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Creates a seniority tier inside the Developers that Scrum does not recognise, and moves the dependency rather than removing it.",
   "A threshold that keeps her in a decision that was never hers. Sprint-Goal risk does not transfer the Developers' accountability for how the work is done to the Scrum Master.",
   "The quality of her calls is not the issue. The Developers decide how the work is done, and every dispute she settles is a decision they are no longer learning to make.",
   "Correct. The accountability boundary is clear — technical approach belongs to the Developers — and the drift is corrected by handing it back with the capability to hold it, not merely by withdrawing."
  ],
  "hard": "C and B both trade on her judgement being good, which is true and irrelevant. The decision is not hers regardless of how well she would make it."
 },
 {
  "n": 8,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Leadership Styles · Coaching",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "Partway through the Sprint, a Developer at a music-licensing company asks the Scrum Master whether the team is allowed to change the technical design it agreed at Sprint Planning, now that it has learned the original approach will not scale.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Ask the Developer what they think the Sprint Backlog's ownership implies, so they reach the answer themselves.",
   "Suggest the change be approved by the Product Owner before proceeding.",
   "Answer directly that the Developers own the Sprint Backlog and may change their plan and approach throughout the Sprint as they learn.",
   "Recommend the team wait until the Retrospective to decide on approach changes."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Coaching where teaching was needed. The Developer lacks a fact, not the capacity to reason, and reflecting the question back reads as a test rather than an answer.",
   "Invents an approval the framework does not require. How the Developers reach the Sprint Goal is theirs; the Product Owner's agreement is not a gate on technical approach.",
   "Correct. This is a settled point and a direct question, so the stance is teaching. The Sprint Backlog is the Developers' plan, updated throughout the Sprint; changing the approach to reach the Sprint Goal is exactly what self-management provides for.",
   "Delays a mid-Sprint decision to an event after the Sprint, and treats a technical-approach change as something to defer rather than something the Developers may simply do."
  ],
  "hard": "A is the reflexive coaching move and B sounds properly consultative. Both withhold a direct answer to a settled question the Developer is entitled to have."
 },
 {
  "n": 9,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability · Technical risk",
  "shape": "Force a decision",
  "type": "single",
  "stem": "At a smart-metering company, the Developers have warned for two Sprints that a third-party service the product depends on is being deprecated in ninety days. The Product Owner keeps agreeing it matters but has not ordered any work. No stakeholder outside the Scrum Team knows.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Ask the Developers to begin the migration now, given the fixed deadline.",
   "Help the Developers express the consequence — what stops working, for whom, and when — so the Product Owner can order it against everything else, and ensure any decision to wait is recorded with a date to revisit.",
   "Escalate to the Product Owner's manager, since a ninety-day deadline on a dependency is too important to leave with one person.",
   "Add the migration work to the Product Backlog so it is no longer overlooked."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Takes the Product Owner's ordering decision, however sound the trajectory looks. The deadline being real does not transfer the accountability.",
   "Correct. Two Sprints of agreement without action is a decision being made by default. The work is to translate the risk into terms the Product Owner can weigh and to ensure that if she chooses to wait, it is a recorded choice with an owner and a review date — not drift.",
   "Premature. The Product Owner has not refused; she has never been given the consequence in terms she can act on. Escalating past her converts a product decision into a governance one before she has genuinely made it.",
   "Crosses the ordering boundary. Adding items to force attention substitutes the Scrum Master's judgement for the Product Owner's, whose accountability the Product Backlog's content is."
  ],
  "hard": "C is the strongest wrong answer: the risk is real and the clock is running, which makes escalation feel responsible. It is wrong about sequence, not about seriousness."
 },
 {
  "n": 10,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability · Events",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "A Scrum Master notices that the Product Owner at a museum-ticketing company approves the Increment privately before each Sprint Review and instructs the Developers on what to show and what to leave out. The Sprint Reviews are smooth and stakeholders are complimentary.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Raise with the whole Scrum Team that curating what stakeholders see undermines the inspection the Sprint Review exists for.",
   "Ask the Product Owner to stop pre-approving the Increment.",
   "Tell the Developers to show the complete Increment regardless of the Product Owner's instructions.",
   "Leave it; the Sprint Reviews run well and stakeholders are satisfied."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. This is a transparency failure affecting the whole Scrum Team, and it belongs in the open with all of them — the Product Owner included, since she is a member of the Scrum Team. Curation defeats the inspect-and-adapt purpose of the event.",
   "Addresses one behaviour privately and misses that this is a Scrum Team matter the Developers are also participating in. It also frames it as the Product Owner's fault rather than a shared failure.",
   "Sets the Developers against the Product Owner and routes around the Scrum Team conversation that should happen. It treats a shared problem as a contest between two accountabilities.",
   "Smooth Sprint Reviews are the symptom. Stakeholders are complimentary because they are inspecting a curated subset, which means the adaptation that should follow is based on an incomplete picture."
  ],
  "hard": "B correctly identifies the behaviour to stop and handles it in the wrong forum, privately, as one person's error rather than a transparency failure the whole team is inside."
 },
 {
  "n": 11,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "A Scrum Master supports one team at a flood-defence agency. She spends most of her week updating a project plan for the programme office, attending programme-office meetings on the team's behalf, and producing status decks.",
  "ask": "Which TWO observations are most relevant?",
  "options": [
   "The project plan should be maintained by the Product Owner instead.",
   "None of these activities is the Scrum Master accountability, and together they crowd out the work that is.",
   "Producing the status decks is acceptable because it protects the team from programme-office demands.",
   "The programme office's need for status is real, and the durable answer is transparency it can read directly rather than decks she produces."
  ],
  "correct": [
   1,
   3
  ],
  "rationale": [
   "Incorrect. Scrum defines no project plan of this kind, so the answer is not to move it to the Product Owner but to question why it exists apart from the Product Backlog.",
   "Correct. Maintaining a project plan, attending meetings as a proxy, and producing decks are none of them coaching, impediment removal, or capability building — and the week they consume is the accountability's actual work.",
   "Incorrect. Shielding the team by producing decks is concealment dressed as protection: the programme office sees a filtered picture and never has to change, and the team never learns to represent its own work.",
   "Correct. The programme office is not the enemy; it has a genuine need for status. Meeting it with transparency it can read for itself — a visible Product Backlog, a Done Increment, real progress — is more durable than decks that make the Scrum Master a permanent intermediary."
  ],
  "hard": "C frames the shielding as a virtue, which is how most Scrum Masters justify it. A relocates an artifact that should be questioned rather than reassigned."
 },
 {
  "n": 12,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability · Scrum Values",
  "shape": "Hold a line",
  "type": "single",
  "stem": "Under deadline pressure at a courier company, a senior manager tells the Scrum Master to instruct the Developers to skip writing automated tests for two Sprints to move faster, framing it as a temporary business decision.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Agree to a single Sprint rather than two, as a compromise.",
   "Pass the instruction to the Developers; the manager has the authority to make business trade-offs.",
   "Explain that how the work is done, including whether it meets the Definition of Done, is not the manager's to direct, and work with him on the deadline pressure behind the request.",
   "Refuse and report the manager to his superior for interfering with the team."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Splits the difference on something that is not divisible. Halving the number of Sprints without tests still concedes that quality is the manager's to trade and the Scrum Master's to broker.",
   "The manager has authority over many things and not over how the Developers build, nor over whether the Increment meets the Definition of Done. Relaying the instruction would make the Scrum Master the channel for undermining both.",
   "Correct. Two lines held at once: the manager may not direct the Developers' method or waive quality, and the deadline pressure that produced the request is real and is worth solving. Holding only the first is rule-keeping; the second is what makes it service.",
   "Escalating before speaking with the person spends credibility and treats a genuine deadline problem as an act of interference to be reported rather than a problem to address."
  ],
  "hard": "A feels like reasonable negotiation and concedes the principle in the act of bargaining over it. The Definition of Done is not a quantity to split."
 },
 {
  "n": 13,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "A team at an air-ambulance charity was assembled from four departments six weeks ago. In Sprint Planning they look to whichever manager happens to attend before committing to anything, even though no manager now has authority over them. Told they are self-managing, they nod and keep looking upward.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Ask managers to stop attending Sprint Planning so the habit has nothing to attach to, while making explicit what the team is now empowered to decide.",
   "Have the Product Owner make the commitments so Sprint Planning can conclude.",
   "Allow Sprint Planning to stall until the team commits without looking up.",
   "Repeat that they are self-managing and encourage them to act on it."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Two preconditions are missing at once — a clear boundary and the safety to act without cover — and both are addressed together: remove the figure the habit attaches to, and state plainly what the team may now decide. The environment is changed rather than the team exhorted.",
   "Installs precisely the dependence the team must leave behind, and moves a Developers' decision to the Product Owner.",
   "Deliberate deprivation of a team that does not yet know what it is allowed to decide. It produces a failed Sprint and evidence that self-management does not work here.",
   "Six weeks of being told they are self-managing has not changed the behaviour, which is evidence that the words are not the missing ingredient. The team is looking up because the boundary of their authority is unclear and a manager is still in the room to look to."
  ],
  "hard": "D is the intervention that has already failed for six weeks, restated. The team lacks a boundary and cover, not encouragement."
 },
 {
  "n": 14,
  "bucket": "Developing People and Teams",
  "focus": "Conflict · Facilitation",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "Two Developers at a stock-photo company clash in most events — one is blunt to the point of dismissiveness, the other has begun withdrawing and now contributes little. The rest of the team has started pre-agreeing decisions in side channels to avoid the friction in the room.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Raise the friction in the Retrospective without naming either Developer, and let the team address it.",
   "Speak with each of the two separately to understand it, then bring them together with a structure; and separately surface that the team's side-channel decisions are removing the events' purpose.",
   "Escalate the interpersonal problem to the pair's line manager.",
   "Ask the blunt Developer to soften their communication style."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "The conflict has moved from ideas to people, past the point a group setting repairs, and anonymity fools no one — both will know. The side channels are also a second problem this option leaves untouched.",
   "Correct. Each needs to say the ungenerous version privately before the generous version is possible together, and the joint conversation needs a structure. The side-channel decisions are a separate fault — the team is quietly hollowing out its own events — and must be named too.",
   "Premature and disproportionate. It converts a recoverable conflict into a performance record and ends the chance of the two resolving it themselves.",
   "Treats one person as the whole problem and asks for a behaviour change without addressing the dynamic between them or the withdrawal it has produced."
  ],
  "hard": "A is the standard move at the wrong escalation stage. B is the only option that also catches the side channels — the mechanism letting the conflict persist unaddressed in the open."
 },
 {
  "n": 15,
  "bucket": "Developing People and Teams",
  "focus": "Coaching and Mentoring",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A capable Product Owner at a vaccine-logistics company is preparing for her first negotiation with a powerful stakeholder who has previously overridden her. She asks the Scrum Master how he would approach it, knowing he has handled similar situations.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Offer to attend and lead the negotiation on her behalf.",
   "Advise her that stakeholder negotiation is the Product Owner's responsibility and hers to work out.",
   "Use open questions so she develops her own negotiation approach.",
   "Share how he has approached comparable situations and what he would do differently, then agree how she wants to handle this one."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Takes over the Product Owner's accountability. Leading her negotiation weakens exactly the standing she is trying to build with this stakeholder.",
   "A boundary used to decline a legitimate request for help. Supporting the Product Owner is part of the accountability, and dismissing her leaves her worse prepared.",
   "Coaching where mentoring was asked for. Reflecting the question back withholds the very thing she came for, when she has a specific event days away and a named, difficult counterpart.",
   "Correct. She has explicitly asked someone with the experience how he would approach it — a request for mentoring. Offering his experience and then agreeing how she wants to handle it gives her something to work from while the decision and the negotiation remain hers."
  ],
  "hard": "C is the reflexive stance and A looks supportive. One withholds what she asked for; the other takes the accountability she is trying to strengthen."
 },
 {
  "n": 16,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a subsea-cable operator, every Retrospective converges on blaming a separate operations team for the Sprint's problems. Nothing within the Scrum Team's own control is examined, and no improvement the team could make itself is ever identified.",
  "ask": "Which TWO approaches are most likely to help?",
  "options": [
   "Facilitate the Retrospective to separate what is within the team's control from what is not, and focus improvement on the former.",
   "Ask the team, for each problem, what they could have done differently regardless of the other team.",
   "Invite the operations team to the Retrospective to answer the complaints.",
   "Move the operations-team problems to a list for management and drop them from the Retrospective."
  ],
  "correct": [
   0,
   1
  ],
  "rationale": [
   "Correct. The Retrospective's value is the improvement the team can make itself. Separating controllable from uncontrollable is a facilitation move that redirects the conversation to where the team has agency.",
   "Correct. Asking what the team could have done differently regardless of the other team is the specific question that breaks a blame loop, because it presumes agency without denying the external cause.",
   "Turns the Retrospective into a cross-team dispute and removes the safety the team needs to examine its own conduct. The operations dependency is real and belongs in a different conversation.",
   "The external dependency is real and worth escalating, but simply removing it from view does not teach the team to find its own improvements — the actual gap."
  ],
  "hard": "C looks like transparency and D looks like escalating a real impediment. Both leave the team's own inability to find self-improvements untouched."
 },
 {
  "n": 17,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams · Events",
  "shape": "Do less than the options suggest",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "When the Developers are handling their own conflict constructively during an event, the Scrum Master should still intervene to guide them toward a resolution.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. A self-managing team's ability to handle its own disagreements is something to protect, not to supersede. Where the Developers are already engaging constructively, intervening — even helpfully — reinserts the Scrum Master into a self-correction that is working and teaches the team that its own conflict needs external management. The Scrum Master's role is to help the team improve its ability to resolve conflict, which sometimes means doing nothing while it does so. Restraint is the harder discipline precisely because intervening always feels useful."
  ],
  "hard": "The word 'constructively' is doing the work and is easy to skim past. The instinct that a Scrum Master should always add value makes the false statement read as true."
 },
 {
  "n": 18,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams · Scrum Values",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "A team at a betting exchange holds lively, honest Retrospectives and generates good improvement ideas, but the ideas rarely happen. By mid-Sprint the improvement has been quietly dropped in favour of delivery work, every Sprint, and nobody objects.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Track the improvement actions in a separate list and review completion each Sprint.",
   "Encourage the team to show more commitment to following through on its improvements.",
   "Help the team select one improvement, make it small enough to finish, and put it in the Sprint Backlog so it competes for capacity with everything else.",
   "Reduce the number of improvements identified so the team is not overwhelmed."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "A tracking mechanism for work that has no capacity. Reviewing completion each Sprint will faithfully record that nothing changed.",
   "Asks for more willpower against a structural problem. The improvements are dropped not because the team lacks commitment but because they were never given capacity and always lose to delivery work.",
   "Correct. The Scrum Guide allows the most impactful improvement to be added to the Sprint Backlog, where it competes for the same capacity as product work rather than being an optional extra. One, small, and visibly funded is what makes it happen.",
   "Fewer good ideas does not make any of them happen. The constraint is capacity and priority, not volume."
  ],
  "hard": "B misreads a capacity problem as a values problem, and A is the tracking reflex that documents the failure without addressing it."
 },
 {
  "n": 19,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation · Leadership Styles",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "During a heated design discussion in Sprint Planning at a fintech, the Scrum Master can see which of the two proposed approaches is sounder, having watched this team hit the same problem before. The Developers are going in circles.",
  "ask": "What is the most appropriate action?",
  "options": [
   "State which approach is better, since he can see it and the team is stuck.",
   "Ask leading questions that steer the Developers toward the sounder approach.",
   "Continue facilitating neutrally and let the Developers reach their own decision however long it takes.",
   "Say explicitly that he is stepping out of facilitation to offer a view, share what he has seen this team hit before, then step back and let them decide."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Deciding the technical approach for the Developers, which is theirs. That he can see the answer does not make it his to give as a ruling.",
   "The dishonest version of contributing. Leading questions steer the outcome while pretending to neutrality, which is worse than either openly deciding or openly advising.",
   "Pure neutrality is rarely available to someone who has watched the team, and withholding relevant experience while they circle is not service — it is hiding behind the facilitator role.",
   "Correct. Separating the roles out loud lets the team weigh his input as one contribution rather than mistaking it for the process or for a decision. He informs the decision without taking it, and the decision stays with the Developers."
  ],
  "hard": "C looks like principled facilitation and B looks like skilled facilitation. One withholds relevant experience; the other smuggles in an opinion while feigning neutrality."
 },
 {
  "n": 20,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "At a home-energy company, the Product Owner orders the Product Backlog strictly by which stakeholder shouted most recently. Genuinely valuable and risky work sinks whenever a loud stakeholder is quiet. She says responsiveness to stakeholders is her job.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Reorder the backlog to reflect value and risk on her behalf.",
   "Ask the loudest stakeholders to route their requests through the Scrum Master for triage.",
   "Accept it; ordering the Product Backlog is the Product Owner's accountability.",
   "Help the Product Owner distinguish ordering by value, risk, and the Product Goal from ordering by whoever is loudest, and support her in managing stakeholders without letting them set the order."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Takes her accountability. Even where the reordering would be better, it is not the Scrum Master's to perform.",
   "Makes the Scrum Master a gatekeeper Scrum does not define, and leaves the Product Owner still ordering by whoever reaches her.",
   "The Product Owner owns the order, and helping her find effective techniques for that is explicitly the Scrum Master's service. Accepting an order driven by volume is not respecting the accountability; it is declining to serve it.",
   "Correct. Ordered means sequenced by value, risk, dependency, cost of delay, and coherence with the Product Goal — not by stakeholder volume. Helping her hold that while still managing stakeholders is the service she needs."
  ],
  "hard": "C hides behind the Product Owner's genuine accountability to avoid serving it. A corrects the order by taking the decision, which repeats the underlying problem."
 },
 {
  "n": 21,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "A team at a hearing-aid manufacturer builds features entirely from the Product Owner's written requirements. None of the Developers has ever met a user, and several design assumptions have recently proven wrong in ways a short conversation with a user would have caught.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Ask the Product Owner to write more detailed requirements so assumptions are not needed.",
   "Create opportunities for the Developers to observe or speak with real users, without displacing the Product Owner's accountability for value.",
   "Add a user representative to the Scrum Team.",
   "Nothing; the Product Owner represents users and writes the requirements."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Attempts to eliminate judgement by specification rather than inform it, produces documents that go stale, and increases the load on the single interpreter.",
   "Correct. Direct contact improves the quality of the countless small decisions Developers make when nobody is available to ask, and it takes nothing from the Product Owner's accountability for maximising value.",
   "Scrum defines three accountabilities and no user-representative role. The fix is contact with users, not a new seat on the team.",
   "The wrong assumptions are the evidence. Requirements passing through a single interpreter arrive stripped of the detail that would have prevented them, and the Developers decide dozens of small things a written requirement cannot cover."
  ],
  "hard": "D is defensible because the Product Owner really is competent, and A is the specification reflex. Neither gives the Developers the direct signal the wrong assumptions show they lack."
 },
 {
  "n": 22,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Managing Technical Risk · Done",
  "shape": "Force a decision",
  "type": "single",
  "stem": "A ride-hailing team keeps a growing list of items marked tech-debt. On inspection it contains two genuine design compromises the team chose deliberately, plus a batch of items where required testing was skipped to hit dates and recorded here instead.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Separate the two design compromises, which are debt the Product Owner orders on value, from the skipped-testing items, which are undone work and a Definition of Done failure that no ordering resolves.",
   "Escalate the skipped testing to whoever owns quality assurance.",
   "Ask the Product Owner to order the whole tech-debt list against the rest of the Product Backlog.",
   "Order the skipped-testing items to the top, since they are the more serious."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. The list conflates two different things. Deliberate design compromises are technical debt that competes on value like anything else. Skipped required testing is undone work — a Definition of Done violation — and the fix is to stop creating it, not to order it.",
   "May follow, and acting before the diagnosis skips the step that distinguishes a Definition of Done breach from a deferred improvement.",
   "Treats the whole list as a prioritisation question. Some of it is; the skipped-testing items are not — they represent work reported as Done that was not, and no position in the backlog makes them Done.",
   "Takes the ordering decision and still misclassifies undone work as a backlog item to be prioritised rather than a violation to be stopped."
  ],
  "hard": "A list labelled tech-debt routinely holds both categories. D and B respond sensibly to the severity while missing that half the list is not a prioritisation question at all."
 },
 {
  "n": 23,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Managing Technical Risk",
  "shape": "Force a decision",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "Since the Scrum Master is not accountable for technical decisions, technical risk lies entirely with the Developers and is not the Scrum Master's concern.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. It is true that the Scrum Master does not make technical decisions; how the work is done belongs to the Developers. But technical risk is a transparency concern, and ensuring risk enters the empirical process rather than accumulating outside it is squarely the Scrum Master's work. That means helping the Developers make risk visible, translating it into terms the Product Owner can weigh, and ensuring decisions about it are taken deliberately by whoever is accountable — none of which requires the Scrum Master to make a technical decision. The premise is accurate; the conclusion drawn from it is not."
  ],
  "hard": "The statement's premise is correct, which lends its false conclusion authority. The distinction is between making technical decisions and ensuring technical risk is transparent."
 },
 {
  "n": 24,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management · Stakeholders",
  "shape": "Sequence correctly",
  "type": "multi",
  "stem": "A capable Product Owner at a national lottery presents her proposed Product Backlog order to a steering board each month; the board reliably reorders it around whichever initiative is most visible to ministers. She has stopped proposing bold sequencing because it never survives. She reports to the board's chair.",
  "ask": "Which TWO are the most appropriate first steps?",
  "options": [
   "Coach the Product Owner to hold firm on her ordering at the next board meeting.",
   "Advise the Product Owner to escalate over the board to the chair.",
   "Understand what the board is accountable for and what problem it is solving by reordering.",
   "Work with the Product Owner to change what the board is asked for — evidence of outcomes against goals rather than a sequence to approve."
  ],
  "correct": [
   2,
   3
  ],
  "rationale": [
   "Sets her up to lose. Asserting authority into a body that outranks her, with nothing about the body changed, asks her to absorb a confrontation on the Scrum Master's behalf — and she has already learned that bold proposals do not survive.",
   "Escalating to the very chair she reports to, over the body he leads, is a confrontation with her own line of authority and among the least likely first steps to help.",
   "Correct, and first. The board is not obviously misbehaving; it likely has a real accountability, probably political, and reorders because it was set up to approve a sequence. Understanding that is the precondition for changing anything.",
   "Correct. A body asked to approve a sequence will amend it. Asked instead whether the product is achieving its intended outcomes, with evidence, it tends to ask better questions and intervene less."
  ],
  "hard": "All four are things that could conceivably happen. The item is about order, and A is the move most candidates reach for before understanding what the board is for."
 },
 {
  "n": 25,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers · Product Value",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a parking-app company, the Product Owner measures success by features shipped per quarter and reports the count to the board. Usage data shows drivers abandoning the app at the payment step at a high rate, but that number appears in no report and shapes no decision.",
  "ask": "Which TWO actions are most appropriate for the Scrum Master?",
  "options": [
   "Help the Product Owner and the board see the gap between features shipped and value actually delivered to drivers.",
   "Support the Product Owner in bringing a value measure, such as payment-step completion, into how success is reported and decided.",
   "Ask the Developers to fix the payment step, since the abandonment rate is clearly the priority.",
   "Tell the board directly that counting features shipped is a poor way to measure success."
  ],
  "correct": [
   0,
   1
  ],
  "rationale": [
   "Correct. The team is measuring output while a large slice of unrealised value sits unexamined at the payment step. Making that gap visible is what lets evidence of value, rather than a feature count, shape what gets built.",
   "Correct. Helping the Product Owner measure what matters is the Scrum Master's service to her. A completion measure connects the team's work to value delivered rather than activity performed, and the decision about it remains hers.",
   "Incorrect. This takes the Product Owner's ordering decision and assumes the fix before anyone has weighed it. The abandonment may well be the priority — that is hers to decide once she can see the evidence.",
   "Incorrect. Right about the measure, wrong in stance and audience. Delivered as a verdict to the board it invites defensiveness and offers nothing to replace the measure with."
  ],
  "hard": "C leaps to a fix, taking a decision the Product Owner should make once she sees the number. D is correct about features-shipped and wrong to deliver it as a verdict to the wrong audience."
 },
 {
  "n": 26,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "A director at a supermarket chain announces that all eight Scrum Teams will be ranked each quarter by story points completed, with the bottom teams required to submit improvement plans. He believes this will drive performance.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Explain why ranking teams by story points will corrupt the estimates and damage collaboration, and offer measures that would actually reveal where teams need help.",
   "Comply and supply the story-point totals; the director sets the measures.",
   "Refuse to supply story points on the grounds that they are not a productivity measure.",
   "Supply the totals with a written explanation of why story points are not comparable across teams."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Both halves matter: why the ranking will backfire — inflated estimates, teams competing instead of collaborating — and what would answer the director's real question about where teams need support. He has a genuine aim; the measure defeats it.",
   "Story points are a Developers' sizing aid, not a cross-team performance measure, and supplying them for ranking guarantees they will be inflated the moment the ranking begins. Compliance produces a confident wrong picture.",
   "Correct about the measure and unhelpful. A flat refusal leaves the director with his problem and usually with a worse number sourced elsewhere.",
   "A caveat that will not survive the first slide the rankings appear on. Once comparative numbers exist, they get compared."
  ],
  "hard": "C is right about story points and abandons the person asking. D is the common compromise that supplies the harmful number with a footnote nobody reads."
 },
 {
  "n": 27,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "At a shipbuilder, Developers' annual bonuses depend on individually completing the tasks assigned to them at the start of each Sprint. As a result they resist taking on anything not in their own list, and helping a colleague costs them. The head of engineering set the scheme and says he needs something objective for finance.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Report the scheme to human resources as incompatible with teamwork.",
   "Coach the Developers to prioritise the Sprint Goal over their individual task lists.",
   "Offer to help the head of engineering design a team-based objective he can defend to finance that does not pit Developers against one another.",
   "Raise the bonus scheme with the Product Owner as an impediment to the Sprint Goal."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Goes over the head of the person who has asked for help, on a scheme he did not design alone, and converts a solvable problem into a dispute.",
   "Asks the Developers to deprioritise the basis of their bonus. That is not a values conversation; it is a request that they take a personal financial risk so the framework works.",
   "Correct. The head of engineering has said what he needs and that nobody has offered an alternative, which is an invitation. The intervention is at the measure, with the person who owns it and is willing to change it.",
   "The Product Owner has no authority over engineering's bonus scheme and no route to change it. It makes the impediment visible to someone who cannot act."
  ],
  "hard": "B repeats the error the situation is built on — asking the least powerful people to absorb the cost of a system nobody has offered to change."
 },
 {
  "n": 28,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "A Scrum Master joins a defence contractor and finds four things wrong: a mandatory sign-off gate before any work starts, Developers split across three programmes each week, a Definition of Done that excludes security accreditation done by a separate cell, and annual project-based funding. Everything is genuinely constrained by regulation somewhere, but not obviously all of it.",
  "ask": "Which should the Scrum Master examine first?",
  "options": [
   "The Definition of Done, since excluding security accreditation is the clearest breach.",
   "Which of the four constraints are genuinely required by regulation and which are established habits the organisation has never questioned.",
   "The split of Developers across three programmes, since unstable membership undermines every team.",
   "The annual project funding, since it is the deepest cause."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "May well be a real breach, and until it is known whether the separate accreditation cell is a regulatory requirement, it is not clear whether the fix is to fold it into Done or to change how the organisation accredits.",
   "Correct. In a regulated setting the first move is to separate genuine constraints from habits, because the two look identical from inside a Sprint and the appropriate action is opposite for each. Everything else depends on that distinction.",
   "A real problem whose remedy depends entirely on whether the split is contractually mandated or merely habitual — which is the distinction that has to come first.",
   "Probably a deep cause and far beyond a new Scrum Master's reach, and acting on any of these before knowing which are law risks challenging a genuine regulatory requirement as though it were a preference."
  ],
  "hard": "D, A, and C each name a genuine problem and a plausible first target. In a regulated setting the enabling first step is the diagnosis that tells you which of them you are even allowed to change."
 },
 {
  "n": 29,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a media-streaming company, a central platform team owns the deployment pipeline that all nine Scrum Teams must use, and it prioritises its own roadmap over the teams' release needs.",
  "ask": "Which of the following are likely consequences? Select all that apply.",
  "options": [
   "The platform team should attend each Scrum Team's Sprint Review.",
   "Release timing is determined by a group outside the Scrum Team, weakening the teams' forecasts.",
   "Teams may quietly narrow their Definition of Done to what they can ship without the platform team.",
   "Scrum Teams cannot reliably release a Done Increment when they are ready."
  ],
  "correct": [
   1,
   2,
   3
  ],
  "rationale": [
   "Incorrect. This is a proposed remedy rather than a consequence, and a weak one — attendance at a Sprint Review does not change the pipeline's priorities or remove the dependency.",
   "Correct. A forecast rests on what the team controls. When release timing is set elsewhere, the team's estimates stop predicting delivery.",
   "Correct. Under pressure to show progress, teams redefine Done to what they can actually ship, which usually means quietly dropping what depends on the platform team.",
   "Correct. When the pipeline's owner prioritises its own roadmap, a team ready to release cannot reliably do so — the ability to deliver a Done Increment depends on a group outside it."
  ],
  "hard": "A is a plausible-sounding action placed among consequences. Select-all items mix categories, and reading the question rather than the options is what catches it."
 },
 {
  "n": 30,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Withdraw or hand over",
  "type": "single",
  "stem": "After two years, a Scrum Master at a weather-services company has built a team that self-manages well, and the surrounding organisation has adapted around it. The team now rarely needs her. A director suggests she move on to a struggling team, and she worries the mature team will regress without her.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Stay with the mature team to protect the gains, since regression is a real risk.",
   "Move immediately and fully, since a self-managing team by definition needs no Scrum Master.",
   "Decline the move and split her time between the two teams.",
   "Treat the team rarely needing her as evidence the accountability has largely succeeded, move to where she is needed, and hand over deliberately rather than disappearing."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "A team that rarely needs her is the goal reached, not a fragile state to guard. Staying to protect gains keeps a capability external that should by now be the team's own.",
   "Overstated in the opposite direction. A self-managing team can still benefit from a Scrum Master; the point is that this one no longer needs this one full-time, and the handover should be deliberate rather than abrupt.",
   "Splits her attention and keeps the mature team partly dependent, when the point of the two years was for it not to need her.",
   "Correct. The measure of the accountability is what survives when the Scrum Master is not there. A team that self-manages well is the success condition; the responsible move is to go where she is needed and hand over deliberately so nothing depends on her presence."
  ],
  "hard": "A dresses the fear of regression as prudence, and B overcorrects into the claim that self-managing teams need no Scrum Master at all. The success condition is being mistaken for a risk."
 }
];
