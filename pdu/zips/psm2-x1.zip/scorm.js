/* SCORM wrapper — detects 1.2 or 2004 automatically, degrades to standalone. */
var SCORM = (function () {
  var api = null, ver = 0, started = false, startedAt = Date.now();

  function scan(win, name) {
    var n = 0;
    while (win && n < 500) {
      if (win[name]) return win[name];
      if (!win.parent || win.parent === win) break;
      win = win.parent; n++;
    }
    return null;
  }

  function discover() {
    var a = scan(window, 'API_1484_11');
    if (!a && window.opener) a = scan(window.opener, 'API_1484_11');
    if (a) { ver = 2004; return a; }
    a = scan(window, 'API');
    if (!a && window.opener) a = scan(window.opener, 'API');
    if (a) { ver = 12; return a; }
    ver = 0; return null;
  }

  function set(k, v) {
    if (!api) return false;
    return (ver === 2004 ? api.SetValue(k, String(v)) : api.LMSSetValue(k, String(v))) === 'true';
  }
  function get(k) {
    if (!api) return '';
    return ver === 2004 ? api.GetValue(k) : api.LMSGetValue(k);
  }
  function commit() {
    if (!api) return false;
    return (ver === 2004 ? api.Commit('') : api.LMSCommit('')) === 'true';
  }

  function hhmmss(ms) {
    var s = Math.floor(ms / 1000),
        h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return p(h) + ':' + p(m) + ':' + p(r);
  }
  function iso(ms) {
    var s = Math.floor(ms / 1000),
        h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    return 'PT' + h + 'H' + m + 'M' + r + 'S';
  }

  return {
    init: function () {
      api = discover();
      if (!api) return false;
      var ok = ver === 2004 ? api.Initialize('') : api.LMSInitialize('');
      started = ok === 'true';
      if (started) {
        if (ver === 2004) {
          if (get('cmi.completion_status') === 'unknown' || get('cmi.completion_status') === '')
            set('cmi.completion_status', 'incomplete');
          set('cmi.score.min', 0); set('cmi.score.max', 100);
        } else {
          var st = get('cmi.core.lesson_status');
          if (!st || st === 'not attempted' || st === 'unknown')
            set('cmi.core.lesson_status', 'incomplete');
          set('cmi.core.score.min', 0); set('cmi.core.score.max', 100);
        }
        commit();
      }
      return started;
    },

    version: function () { return ver; },
    connected: function () { return !!api && started; },

    suspend: function (str) {
      if (!api) return;
      set(ver === 2004 ? 'cmi.suspend_data' : 'cmi.suspend_data', str);
      set(ver === 2004 ? 'cmi.exit' : 'cmi.core.exit', 'suspend');
      commit();
    },
    resume: function () { return api ? get('cmi.suspend_data') : ''; },

    /* one cmi.interactions entry per question */
    interaction: function (i, q, response, correctResp, isRight, latencyMs) {
      if (!api) return;
      var p = 'cmi.interactions.' + i + '.';
      var typ = q.type === 'tf' ? 'true-false' : 'choice';
      if (ver === 2004) {
        set(p + 'id', 'Q' + q.n);
        set(p + 'type', typ);
        set(p + 'description', q.bucket);
        set(p + 'learner_response', response);
        set(p + 'correct_responses.0.pattern', correctResp);
        set(p + 'result', isRight ? 'correct' : 'incorrect');
        set(p + 'weighting', 1);
        set(p + 'latency', iso(latencyMs));
        set(p + 'timestamp', new Date().toISOString().replace(/\.\d+Z$/, 'Z'));
      } else {
        set(p + 'id', 'Q' + q.n);
        set(p + 'type', typ);
        set(p + 'student_response', response);
        set(p + 'correct_responses.0.pattern', correctResp);
        set(p + 'result', isRight ? 'correct' : 'wrong');
        set(p + 'weighting', 1);
        set(p + 'time', new Date().toTimeString().slice(0, 8));
        set(p + 'latency', hhmmss(latencyMs));
      }
    },

    finish: function (pct, passed, elapsedMs) {
      if (!api) return;
      if (ver === 2004) {
        set('cmi.score.raw', pct);
        set('cmi.score.scaled', (pct / 100).toFixed(4));
        set('cmi.completion_status', 'completed');
        set('cmi.success_status', passed ? 'passed' : 'failed');
        set('cmi.session_time', iso(elapsedMs));
        set('cmi.exit', '');
      } else {
        set('cmi.core.score.raw', pct);
        set('cmi.core.lesson_status', passed ? 'passed' : 'failed');
        set('cmi.core.session_time', hhmmss(elapsedMs));
        set('cmi.core.exit', '');
      }
      commit();
      try { ver === 2004 ? api.Terminate('') : api.LMSFinish(''); } catch (e) {}
      started = false;
    }
  };
})();
