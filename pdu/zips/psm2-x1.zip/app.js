/* Between the Rules — Practice Exam 1 player */
(function () {
  var LETTERS = 'ABCD';
  var TOTAL = QUESTIONS.length;
  var LIMIT_MS = META.minutes * 60 * 1000;

  var state = {
    answers: {},      // n -> [indices]
    flags: {},        // n -> bool
    idx: 0,
    started: false,
    submitted: false,
    startAt: 0,
    seen: {}          // n -> ms first shown
  };

  var $ = function (s) { return document.querySelector(s); };
  var app = $('#app');
  var timerEl = null, tick = null;

  /* ───────── helpers ───────── */
  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function answered(n) { return (state.answers[n] || []).length > 0; }
  function countAnswered() {
    return QUESTIONS.filter(function (q) { return answered(q.n); }).length;
  }
  function isRight(q) {
    var a = (state.answers[q.n] || []).slice().sort().join(',');
    return a === q.correct.slice().sort().join(',');
  }
  function score() {
    var right = QUESTIONS.filter(isRight).length;
    return { right: right, pct: Math.round(right / TOTAL * 100) };
  }
  function typeLabel(t) {
    return t === 'single' ? 'Multiple choice'
         : t === 'multi' ? 'Multiple response' : 'True / False';
  }
  function instruction(q) {
    if (q.type === 'tf') return 'Select one.';
    if (q.type === 'single') return 'Select one.';
    return q.correct.length === 2 ? 'Select two.' : 'Select all that apply.';
  }

  /* ───────── persistence ───────── */
  function pack() {
    var a = QUESTIONS.map(function (q) {
      return (state.answers[q.n] || []).join('') + (state.flags[q.n] ? 'f' : '');
    }).join('|');
    return state.idx + '~' + Math.round((Date.now() - state.startAt) / 1000) + '~' + a;
  }
  function unpack(s) {
    if (!s || s.indexOf('~') < 0) return false;
    var p = s.split('~');
    state.idx = parseInt(p[0], 10) || 0;
    var elapsed = (parseInt(p[1], 10) || 0) * 1000;
    state.startAt = Date.now() - elapsed;
    (p[2] || '').split('|').forEach(function (chunk, i) {
      var q = QUESTIONS[i]; if (!q) return;
      if (chunk.indexOf('f') > -1) { state.flags[q.n] = true; chunk = chunk.replace('f', ''); }
      if (chunk.length) state.answers[q.n] = chunk.split('').map(Number);
    });
    return true;
  }
  function save() { if (state.started && !state.submitted) SCORM.suspend(pack()); }

  /* ───────── timer ───────── */
  function remaining() { return Math.max(0, LIMIT_MS - (Date.now() - state.startAt)); }
  function fmt(ms) {
    var s = Math.floor(ms / 1000), m = Math.floor(s / 60), r = s % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  }
  function startTimer() {
    if (tick) clearInterval(tick);
    tick = setInterval(function () {
      if (state.submitted) { clearInterval(tick); return; }
      var r = remaining();
      if (timerEl) {
        timerEl.textContent = fmt(r);
        timerEl.className = 'timer' + (r < 5 * 60 * 1000 ? ' low' : '');
      }
      if (r <= 0) { clearInterval(tick); submit(true); }
    }, 500);
  }

  /* ───────── screens ───────── */
  function renderStart(resuming) {
    app.innerHTML =
      '<div class="screen start">' +
      '<p class="eyebrow">Between the Rules · Professional Scrum Master II</p>' +
      '<h1>Practice Exam One</h1>' +
      '<p class="lede">Thirty questions across the five assessment areas. Sit it under real conditions — the value is in the conditions, not the score.</p>' +
      '<div class="facts">' +
        '<div><span>Questions</span><b>' + TOTAL + '</b></div>' +
        '<div><span>Time</span><b>' + META.minutes + ' min</b></div>' +
        '<div><span>Pass mark</span><b>' + META.pass_mark + '%</b></div>' +
        '<div><span>To pass</span><b>' + META.pass_count + ' / ' + TOTAL + '</b></div>' +
      '</div>' +
      '<ul class="rules">' +
        '<li><b>Read the instruction on every question.</b> Some ask for one answer, some for two, and some say <i>select all that apply</i> — where the number correct is not stated and may be all of them.</li>' +
        '<li><b>Partial answers score nothing.</b> On multiple-response questions you must select every correct option and no incorrect one.</li>' +
        '<li><b>The clock does not stop.</b> At time the exam submits whatever you have.</li>' +
        '<li><b>Answer everything.</b> There is no penalty beyond the mark itself.</li>' +
      '</ul>' +
      '<div class="note"><b>How these questions work.</b> Most describe a situation and ask what a Scrum Master should do. More than one option is usually defensible, and several turn on <i>sequence</i> — which correct action comes first. Where two look right, ask which leaves the accountability where Scrum put it, and which leaves the team more capable afterwards.</div>' +
      '<button class="btn primary" id="go">' + (resuming ? 'Resume exam' : 'Begin exam') + '</button>' +
      '<p class="conn">' + (SCORM.connected()
          ? 'Connected to your LMS — progress and results will be recorded.'
          : 'Running without an LMS connection. Results will not be recorded.') + '</p>' +
      '</div>';
    $('#go').onclick = function () {
      if (!resuming) state.startAt = Date.now();
      state.started = true;
      renderQ(); startTimer();
    };
  }

  function renderQ() {
    var q = QUESTIONS[state.idx];
    if (!state.seen[q.n]) state.seen[q.n] = Date.now();
    var multi = q.type === 'multi';
    var chosen = state.answers[q.n] || [];

    var opts = q.options.map(function (o, i) {
      var on = chosen.indexOf(i) > -1;
      return '<li class="opt' + (on ? ' on' : '') + '" data-i="' + i + '">' +
             '<span class="box' + (multi ? ' sq' : '') + '">' +
             (q.type === 'tf' ? (i === 0 ? 'T' : 'F') : LETTERS[i]) + '</span>' +
             '<span class="otxt">' + esc(o) + '</span></li>';
    }).join('');

    app.innerHTML =
      '<div class="screen">' + bar() +
      '<div class="qwrap">' +
        '<p class="qmeta"><b>' + esc(q.bucket) + '</b> · ' + typeLabel(q.type) + '</p>' +
        '<p class="stem">' + esc(q.stem) + '</p>' +
        '<p class="ask">' + esc(q.ask) + '</p>' +
        '<p class="inst">' + instruction(q) + '</p>' +
        '<ul class="opts">' + opts + '</ul>' +
      '</div>' +
      '<div class="nav">' +
        '<button class="btn" id="prev"' + (state.idx === 0 ? ' disabled' : '') + '>Previous</button>' +
        '<button class="btn flag' + (state.flags[q.n] ? ' on' : '') + '" id="flag">' +
          (state.flags[q.n] ? 'Flagged' : 'Flag for review') + '</button>' +
        '<button class="btn primary" id="next">' +
          (state.idx === TOTAL - 1 ? 'Review answers' : 'Next') + '</button>' +
      '</div>' + grid() + '</div>';

    timerEl = $('#timer');
    Array.prototype.forEach.call(document.querySelectorAll('.opt'), function (el) {
      el.onclick = function () {
        var i = +el.dataset.i, cur = state.answers[q.n] || [];
        if (multi) {
          var at = cur.indexOf(i);
          if (at > -1) cur.splice(at, 1); else cur.push(i);
          state.answers[q.n] = cur;
        } else {
          state.answers[q.n] = [i];
        }
        save(); renderQ();
      };
    });
    $('#prev').onclick = function () { if (state.idx > 0) { state.idx--; save(); renderQ(); } };
    $('#next').onclick = function () {
      if (state.idx === TOTAL - 1) { renderReview(); }
      else { state.idx++; save(); renderQ(); }
    };
    $('#flag').onclick = function () {
      state.flags[q.n] = !state.flags[q.n]; save(); renderQ();
    };
    wireGrid();
  }

  function bar() {
    return '<div class="bar">' +
      '<div class="pos">Question <b>' + (state.idx + 1) + '</b> of ' + TOTAL + '</div>' +
      '<div class="prog"><i style="width:' + (countAnswered() / TOTAL * 100) + '%"></i></div>' +
      '<div class="tw"><span>Time left</span><span class="timer" id="timer">' +
        fmt(remaining()) + '</span></div></div>';
  }

  function grid() {
    var cells = QUESTIONS.map(function (q, i) {
      var c = 'g' + (answered(q.n) ? ' done' : '') + (state.flags[q.n] ? ' flag' : '') +
              (i === state.idx ? ' here' : '');
      return '<button class="' + c + '" data-g="' + i + '">' + q.n + '</button>';
    }).join('');
    return '<div class="gridwrap"><p class="glabel">Jump to question</p><div class="grid">' +
           cells + '</div><p class="key"><i class="sw done"></i>answered ' +
           '<i class="sw flag"></i>flagged <i class="sw"></i>unanswered</p></div>';
  }
  function wireGrid() {
    Array.prototype.forEach.call(document.querySelectorAll('.g'), function (b) {
      b.onclick = function () { state.idx = +b.dataset.g; save(); renderQ(); };
    });
  }

  function renderReview() {
    var un = QUESTIONS.filter(function (q) { return !answered(q.n); });
    var fl = QUESTIONS.filter(function (q) { return state.flags[q.n]; });
    var list = function (arr) {
      return arr.length
        ? '<div class="chips">' + arr.map(function (q) {
            return '<button class="chip" data-g="' + QUESTIONS.indexOf(q) + '">' + q.n + '</button>';
          }).join('') + '</div>'
        : '<p class="none">None.</p>';
    };
    app.innerHTML =
      '<div class="screen">' + bar() +
      '<div class="qwrap review">' +
        '<h2>Before you submit</h2>' +
        '<p class="lede">You have answered <b>' + countAnswered() + ' of ' + TOTAL + '</b>. ' +
          'Unanswered questions score nothing, so answer everything even where you are unsure.</p>' +
        '<h3>Unanswered</h3>' + list(un) +
        '<h3>Flagged for review</h3>' + list(fl) +
        '<div class="nav" style="margin-top:2rem">' +
          '<button class="btn" id="back">Back to questions</button>' +
          '<button class="btn primary" id="sub">Submit exam</button>' +
        '</div>' +
      '</div></div>';
    timerEl = $('#timer');
    Array.prototype.forEach.call(document.querySelectorAll('.chip'), function (b) {
      b.onclick = function () { state.idx = +b.dataset.g; renderQ(); };
    });
    $('#back').onclick = function () { renderQ(); };
    $('#sub').onclick = function () {
      if (confirm('Submit your exam? You will not be able to change your answers.')) submit(false);
    };
  }

  /* ───────── submit + results ───────── */
  function submit(auto) {
    if (state.submitted) return;
    state.submitted = true;
    if (tick) clearInterval(tick);
    var elapsed = Math.min(Date.now() - state.startAt, LIMIT_MS);
    var s = score(), passed = s.pct >= META.pass_mark;

    QUESTIONS.forEach(function (q, i) {
      var chosen = (state.answers[q.n] || []).slice().sort();
      var toId = function (ix) {
        return q.type === 'tf' ? (ix === 0 ? 'true' : 'false') : LETTERS[ix].toLowerCase();
      };
      var sep = SCORM.version() === 2004 ? '[,]' : ',';
      SCORM.interaction(i, q,
        chosen.map(toId).join(sep),
        q.correct.slice().sort().map(toId).join(sep),
        isRight(q),
        Math.max(0, Date.now() - (state.seen[q.n] || Date.now())));
    });
    SCORM.finish(s.pct, passed, elapsed);
    renderResults(s, passed, elapsed, auto);
  }

  function renderResults(s, passed, elapsed, auto) {
    var byArea = {};
    QUESTIONS.forEach(function (q) {
      var b = byArea[q.bucket] || (byArea[q.bucket] = { n: 0, r: 0 });
      b.n++; if (isRight(q)) b.r++;
    });
    var byShape = {};
    QUESTIONS.forEach(function (q) {
      if (isRight(q)) return;
      byShape[q.shape] = (byShape[q.shape] || 0) + 1;
    });

    var areaRows = Object.keys(byArea).map(function (k) {
      var b = byArea[k], p = Math.round(b.r / b.n * 100);
      return '<tr><td>' + esc(k) + '</td><td class="num">' + b.r + ' / ' + b.n + '</td>' +
             '<td class="barcell"><i style="width:' + p + '%" class="' +
             (p >= 85 ? 'ok' : p >= 60 ? 'mid' : 'low') + '"></i></td>' +
             '<td class="num">' + p + '%</td></tr>';
    }).join('');

    var shapeNote = Object.keys(byShape).length
      ? '<p class="shapes"><b>Where your misses cluster:</b> ' +
        Object.keys(byShape).sort(function (a, b) { return byShape[b] - byShape[a]; })
          .map(function (k) { return esc(k) + ' (' + byShape[k] + ')'; }).join(' · ') + '</p>'
      : '';

    var review = QUESTIONS.map(function (q) {
      var ok = isRight(q), chosen = state.answers[q.n] || [];
      var opts = q.options.map(function (o, i) {
        var cor = q.correct.indexOf(i) > -1, pick = chosen.indexOf(i) > -1;
        var cls = 'ro' + (cor ? ' cor' : '') + (pick && !cor ? ' wrong' : '');
        var mark = cor ? '✓' : (pick ? '✕' : '');
        return '<li class="' + cls + '"><span class="rb">' +
               (q.type === 'tf' ? (i === 0 ? 'T' : 'F') : LETTERS[i]) + '</span>' +
               '<span class="rt"><b>' + esc(o) + '</b> — ' + esc(q.rationale[i] || '') + '</span>' +
               '<span class="rm">' + mark + '</span></li>';
      }).join('');
      return '<div class="rq ' + (ok ? 'ok' : 'no') + '">' +
        '<h4><span class="rn">' + q.n + '</span> ' + esc(q.bucket) +
          '<em>' + (ok ? 'Correct' : 'Incorrect') + '</em></h4>' +
        '<p class="rtags">' + typeLabel(q.type) + ' · ' + esc(q.focus) + ' · Shape: ' + esc(q.shape) + '</p>' +
        '<p class="rstem">' + esc(q.stem) + '</p><p class="rask">' + esc(q.ask) + '</p>' +
        '<ul class="ropts">' + opts + '</ul>' +
        '<div class="rwhy"><b>Why this one is difficult.</b> ' + esc(q.hard) + '</div></div>';
    }).join('');

    app.innerHTML =
      '<div class="screen results">' +
      '<div class="verdict ' + (passed ? 'pass' : 'fail') + '">' +
        '<p class="eyebrow">Practice Exam One · Result</p>' +
        '<div class="big">' + s.pct + '%</div>' +
        '<p class="sum"><b>' + s.right + ' of ' + TOTAL + ' correct.</b> ' +
          (passed ? 'Above the ' + META.pass_mark + '% pass mark.'
                  : 'Below the ' + META.pass_mark + '% pass mark — ' +
                    (META.pass_count - s.right) + ' more needed.') + '</p>' +
        '<p class="time">Time used: ' + Math.floor(elapsed / 60000) + ' min ' +
          Math.floor((elapsed % 60000) / 1000) + ' sec' +
          (auto ? ' · submitted automatically at time' : '') + '</p>' +
      '</div>' +
      '<h2>By assessment area</h2>' +
      '<table class="areas"><thead><tr><th>Area</th><th class="num">Score</th><th></th><th class="num">%</th></tr></thead>' +
        '<tbody>' + areaRows + '</tbody></table>' + shapeNote +
      '<div class="note"><b>How to read this.</b> Three or more misses in one area is a study instruction. Misses scattered evenly usually mean the difficulty is with reading the question rather than with the material — particularly on items that turn on sequence.</div>' +
      '<h2>Every question explained</h2>' +
      '<p class="lede">Read the reasoning on questions you answered correctly too. A right answer chosen for the wrong reason will not survive a differently worded question.</p>' +
      review + '</div>';
    window.scrollTo(0, 0);
  }

  /* ───────── boot ───────── */
  SCORM.init();
  var prior = SCORM.resume();
  var resuming = prior && unpack(prior) && countAnswered() > 0 && remaining() > 0;
  renderStart(!!resuming);
  window.addEventListener('beforeunload', save);
})();
