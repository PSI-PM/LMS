var META = {"minutes": 90, "pass_mark": 85, "pass_count": 26};
var QUESTIONS = [
 {
  "n": 1,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Artifacts · Events",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "An online grocery company runs three-week Sprints. Midway through a Sprint, the Developers identify a technical approach that reaches the Sprint Goal sooner but abandons two of the five Product Backlog items they selected at Sprint Planning. The Product Owner is on leave for three days. There is no external deadline.",
  "ask": "What should the Developers do?",
  "options": [
   "Continue with the five selected items, because changing the Sprint Backlog without the Product Owner undermines transparency.",
   "Adopt the new approach, update the Sprint Backlog, and discuss the change with the Product Owner when they return.",
   "Adopt the new approach only if the two dropped items are committed to the next Sprint.",
   "Wait for the Product Owner to return before changing anything, so the forecast stays intact."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "The Sprint Backlog is by and for the Developers and is updated throughout the Sprint as more is learned. Treating the items selected at Sprint Planning as fixed confuses the forecast with the commitment.",
   "Correct. The Sprint Goal is the commitment; the selected items are a forecast. The Developers decide how to reach the goal and own their plan. Nothing requires the Product Owner's approval for a change in approach that still achieves the goal — and the Product Owner is told at the earliest opportunity.",
   "This invents a rule Scrum does not contain. What happens to unselected items is a Product Backlog ordering decision belonging to the Product Owner, not a condition the Developers may attach.",
   "Three days of avoidable delay in service of protecting a forecast. The forecast is not the thing being protected; the Sprint Goal is, and it is not at risk."
  ],
  "hard": "A and D both sound properly deferential and invoke transparency, which is why they attract. The item tests whether a candidate treats the selected items as a promise."
 },
 {
  "n": 2,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Done",
  "shape": "Hold a line",
  "type": "single",
  "stem": "A medical device manufacturer has an organisational Definition of Done that requires traceability documentation for all software. One Scrum Team builds an internal scheduling tool that falls outside the regulated product line. The team argues the documentation adds no value for their product and proposes dropping that clause for their work only.",
  "ask": "What is the most appropriate response from the Scrum Master?",
  "options": [
   "Report the team's proposed non-compliance to the quality function.",
   "Support the team provided the Product Owner agrees the value trade-off.",
   "Explain that the organisational standard is a minimum the team may add to but not subtract from, and help them take the case for changing the standard to whoever owns it.",
   "Support the team, because the Scrum Team creates a Definition of Done appropriate for its product."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Treats a reasonable proposal, openly raised, as a compliance matter. It also removes the team's ability to make their case and teaches them that raising things is punished.",
   "The Product Owner is accountable for maximising value, not for waiving an organisational quality standard. Adding the Product Owner's agreement does not create an authority nobody in the Scrum Team holds.",
   "Correct. Teams may be stricter than an organisational standard and never looser. The team's argument may well be right — which is why the response is not simply to refuse, but to route the argument to whoever can change the standard.",
   "This quotes a real sentence from the Scrum Guide and applies it in the wrong case. A Scrum Team creates the Definition of Done only where the organisation does not have one. Where a standard exists, all Scrum Teams follow it as a minimum."
  ],
  "hard": "D is a correct sentence from the framework deployed in the wrong condition, which is the most reliable way to make a wrong answer look authoritative."
 },
 {
  "n": 3,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Events",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A mapping software team's Daily Scrum regularly runs to twenty-five minutes because the Developers use it to solve problems as they surface. The Developers say they find it valuable. For the last month the Scrum Master has been ending the event at fifteen minutes, and several Developers have said this leaves problems hanging.",
  "ask": "What should the Scrum Master do?",
  "options": [
   "Continue enforcing the fifteen-minute timebox, since the event is defined and timeboxes are not optional.",
   "Move the problem-solving into a separate scheduled session later in the day.",
   "Keep the timebox and help the Developers see that the detailed problem-solving can continue immediately afterwards with only the people it concerns.",
   "Allow the event to run to twenty-five minutes, since the Developers find it valuable and the Daily Scrum is theirs."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Correct on the rule and wrong on the service. Ending the event without addressing what the Developers actually need leaves them with a worse arrangement and no explanation, which is why they are frustrated.",
   "Adds a meeting to solve a problem that does not need one, and delays the discussion by hours for no benefit.",
   "Correct. The Daily Scrum is fifteen minutes and the Developers' need to solve problems is real; both can be true. Deep discussions are taken immediately afterwards with whoever is needed, which also stops the whole team sitting through conversations that concern two people.",
   "The timebox is a maximum, not a preference the Developers may extend. Their ownership of the event does not extend to changing its definition."
  ],
  "hard": "A is technically correct and is what most candidates have been taught to do. The distinction being tested is between enforcing a rule and serving the team's effectiveness while keeping the rule intact."
 },
 {
  "n": 4,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Done · Artifacts",
  "shape": "Hold a line",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "A Scrum Team may present an Increment at the Sprint Review that does not fully meet the Definition of Done, provided the Product Owner accepts it and the outstanding work is recorded for a later Sprint.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. Work that does not meet the Definition of Done is not part of the Increment, is not presented as complete, and returns to the Product Backlog. The Product Owner cannot waive this; it is not their decision to make. Recording the gap as a follow-up item is the specific anti-pattern that makes the failure invisible: the item is counted as progress, the forecast is built on a false base, and the residual risk moves somewhere nobody with authority reads."
  ],
  "hard": "The statement contains two plausible-sounding safeguards — Product Owner acceptance and a written record — and both are irrelevant to whether the work is Done."
 },
 {
  "n": 5,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Events · Scrum Team",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "A ticketing platform runs three-week Sprints. Two weeks into a Sprint, a regulator prohibits the feature the Sprint Goal was built around. Several Product Backlog items in the Sprint are already finished and meet the Definition of Done.",
  "ask": "Which of the following are true? Select all that apply.",
  "options": [
   "The Sprint Goal has become obsolete, which is the condition under which a Sprint may be cancelled.",
   "The Scrum Master should cancel the Sprint, since continuing would produce waste.",
   "Completed items that meet the Definition of Done may be reviewed and potentially released; the remaining items return to the Product Backlog.",
   "Only the Product Owner has the authority to cancel the Sprint."
  ],
  "correct": [
   0,
   2,
   3
  ],
  "rationale": [
   "Correct. Obsolescence of the Sprint Goal is the condition. A regulatory prohibition is a textbook case: achieving the goal would no longer be valuable, as distinct from the work merely being late or harder than expected.",
   "Incorrect. The diagnosis is right and the authority is wrong. A Scrum Master who cancels a Sprint has taken a decision that Scrum places with one person.",
   "Correct. Done work may be reviewed and potentially released; everything else returns to the Product Backlog. The team then holds Sprint Planning to begin a new Sprint.",
   "Correct. Cancellation authority rests with the Product Owner alone — not the Scrum Master, not the Developers, not a stakeholder or regulator."
  ],
  "hard": "B is correct about the situation and wrong about who acts, which is the most common way cancellation is tested."
 },
 {
  "n": 6,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Scrum Team",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "An audio streaming company has a Scrum Team of fourteen people. Over time it has split informally into a front-end group and a back-end group with separate daily conversations and separate portions of the Sprint Backlog. They share one Product Owner, one Sprint Goal and one Sprint Review. Delivery has been stable for six months.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Leave the arrangement in place, since it is delivering and Scrum's guidance on team size is not a rule.",
   "Split the group into two Scrum Teams immediately and appoint a second Scrum Master.",
   "Formalise the split into two Scrum Teams, each with its own Sprint Goal and Scrum Master.",
   "Make the situation transparent to the Scrum Team — they are operating as sub-teams, which Scrum does not permit — and facilitate the team deciding how to resolve it."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Scrum is explicit that a Scrum Team has no sub-teams. The arrangement's stability is not evidence that it is sound; it is the reason nobody has questioned it.",
   "Same error as B with more force. It also assumes the answer before the team has examined the problem.",
   "The right destination reached by the wrong route. Restructuring is not the Scrum Master's decision, and imposing it removes the team from a decision about how they work.",
   "Correct. The Scrum Master's accountability is to make the situation visible and help the team address it. Whether the answer is two Scrum Teams, a smaller team, or genuine cross-functionality within one, that is for the Scrum Team and the organisation to work out."
  ],
  "hard": "C and B are both defensible outcomes. What separates them from the correct answer is who decides — and stable delivery makes leaving it alone genuinely tempting."
 },
 {
  "n": 7,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Withdraw or hand over",
  "type": "single",
  "stem": "A Scrum Master at a freight forwarding company has maintained the team's impediment log for eighteen months, chasing each item and reporting resolution times weekly. Impediments are cleared quickly and the team is complimentary about it. During a recent two-week absence, no impediments were recorded at all.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Share the observation with the team, hand over one category of impediment, stay present while they take it on, and resist reclaiming it.",
   "Hand the log to the Developers and step away from it so they learn to own it.",
   "Continue the current approach, since impediments are being resolved quickly and the team values it.",
   "Ask the Product Owner to maintain the log during future absences."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Withdrawal is a deliberate, incremental practice: name it, hand over a piece, remain available while it goes imperfectly, and do not take it back at the first difficulty.",
   "Right diagnosis, wrong execution. A team that has never held the practice does not acquire it by having the support removed; it acquires a bad fortnight and a belief that the change did not work. Capability has to be built before the support is withdrawn.",
   "The absence is the evidence. Fast resolution while the Scrum Master is present, and nothing at all while they are not, describes a team that has outsourced a capability rather than developed one.",
   "Moves the dependency rather than removing it, and puts a Developers' concern into the Product Owner's hands."
  ],
  "hard": "Every visible signal says this Scrum Master is doing the job well. The item tests whether indispensability is read as success or as a failure of the accountability."
 },
 {
  "n": 8,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Leadership Styles · Coaching",
  "shape": "Choose a different stance",
  "type": "multi",
  "stem": "At a university, a Developer asks the Scrum Master privately whether a partially tested item can be shown at the Sprint Review, because the Product Owner has asked for it to be demonstrated to a funding body. The team's Definition of Done requires the testing.",
  "ask": "Which TWO responses are most appropriate?",
  "options": [
   "Suggest the Developer raise the question with the whole Scrum Team so the decision belongs to the team.",
   "Ask the Developer what they believe the Definition of Done implies, so they reach the conclusion themselves.",
   "Answer directly that work not meeting the Definition of Done is not part of the Increment and is not presented as complete.",
   "Bring the underlying situation — a Product Owner asking for undone work to be demonstrated — into the open with the Scrum Team."
  ],
  "correct": [
   2,
   3
  ],
  "rationale": [
   "Diffuses a settled rule into a group decision. Whether an Increment meeting the Definition of Done may be presented is not a matter for team deliberation, and framing it as one implies the outcome is negotiable.",
   "Coaching used where teaching was required. The Developer is not short of capacity to reason; they are short of a fact, and they are asking someone who has it.",
   "Correct. The gap here is knowledge and the answer is settled. A direct question under time pressure deserves a direct answer, and withholding one teaches the Developer that asking is unproductive.",
   "Correct. The individual question is easy; the situation behind it is not, and it will recur. The pressure on the Definition of Done is a Scrum Team matter and belongs in the open."
  ],
  "hard": "B is the reflexive answer for an experienced Scrum Master and is the most abused stance in the accountability. Distinguishing a knowledge gap from a capability gap is the whole item."
 },
 {
  "n": 9,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability · Technical risk",
  "shape": "Force a decision",
  "type": "single",
  "stem": "At a payments processor, the Developers raised four months ago that a core library is no longer supported by its maintainer. It has appeared in every Sprint Retrospective since. The Product Owner has never ordered any work relating to it into the Product Backlog. There has been no incident. Nobody outside the Scrum Team is aware of it.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Help the Developers express the exposure in terms of what would happen, to whom, and on what timescale; ensure it reaches the Product Owner; and ensure any decision to defer is recorded with an owner and a review date.",
   "Add an item to the Product Backlog so the issue stops disappearing between Sprints.",
   "Stop raising it in Retrospectives, since repeatedly surfacing an unactioned item wastes the team's time.",
   "Escalate to the Chief Technology Officer, since an unsupported library in a payments system exceeds a single Product Owner's authority."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Four months without a decision is a decision being made by default. The outcome to protect is a deliberate choice by the accountable person, with the information — not necessarily the choice the Scrum Master would make.",
   "Crosses a boundary. The Product Owner is accountable for the Product Backlog's content and ordering, and a Scrum Master adding items to force attention substitutes their judgement for the accountable person's.",
   "Abandons the impediment. Repetition without effect is a signal that the transparency is not landing, not that it should stop.",
   "Genuinely arguable, and premature. The Product Owner has not refused — they have never been given the exposure in terms they could weigh. Escalating past an accountable person who has not been properly informed converts a product decision into a governance one you cannot walk back."
  ],
  "hard": "D is the most attractive wrong answer in the exam. It is correct that the risk is serious and correct that someone senior should eventually know; it is wrong about sequence."
 },
 {
  "n": 10,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Empiricism · Artifacts",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "A Scrum Master at a hotel group discovers that the environment used for the last three Sprint Reviews is seeded with synthetic data that conceals a known performance problem under real load. The Developers set it up this way and are aware. The Product Owner is not, and has been telling stakeholders the product is ready for a pilot.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Tell the Product Owner immediately, since they have been misled about the state of the product.",
   "Demonstrate the real behaviour under load at the next Sprint Review without warning, so the transparency failure is unmistakable.",
   "Raise it with the whole Scrum Team at the earliest opportunity, so the Developers and the Product Owner confront the gap together.",
   "Raise it privately with the Developers and ask them to change the environment before the next Sprint Review."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Gets the information to someone who can act, but routes around the Developers and casts the Scrum Master as the reporter of the team to the Product Owner. It also removes the Developers' opportunity to own what they did.",
   "An ambush. It makes the point at the cost of the team's trust and treats a transparency failure as an occasion for a demonstration.",
   "Correct. The Product Owner and the Developers are all members of the Scrum Team, so there is no need to choose between informing one and involving the other. Doing it together preserves the Developers' agency and gets the correction into the same conversation.",
   "Fixes the environment and leaves the Product Owner misinformed about three Sprints of history, still briefing stakeholders on a false picture."
  ],
  "hard": "A is the answer most candidates pick, and it is nearly right. The discriminator is that the Product Owner is inside the Scrum Team, which makes a single conversation available."
 },
 {
  "n": 11,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Team · Artifacts",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "At an insurance company, the Product Owner has begun telling individual Developers which Sprint Backlog items to work on each day. The Developers have not objected. Delivery has been steady.",
  "ask": "Which of the following are possible consequences? Select all that apply.",
  "options": [
   "The Product Owner has less time for Product Backlog management and stakeholder collaboration.",
   "The Developers stop proposing better routes to the Sprint Goal.",
   "The Developers' accountability for the Sprint Backlog is undermined.",
   "The Sprint Goal becomes a set of assigned tasks rather than a single objective."
  ],
  "correct": [
   0,
   1,
   2,
   3
  ],
  "rationale": [
   "Correct. Daily direction of Developers is time not spent on the Product Backlog, the Product Goal, or stakeholders — the work only the Product Owner can do.",
   "Correct. People who are told what to do stop offering alternatives, and the team's ability to adapt within the Sprint declines with it.",
   "Correct. The Sprint Backlog is by and for the Developers, including who does what and when. Daily direction from outside removes exactly that.",
   "Correct. Where work is assigned item by item, the Sprint Goal degrades into a description of the assignments rather than an objective the plan serves."
  ],
  "hard": "Every option is correct. Candidates who assume a multiple-response item must contain a distractor will leave marks behind looking for one."
 },
 {
  "n": 12,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Events · Leadership Styles",
  "shape": "Hold a line",
  "type": "single",
  "stem": "At a broadcaster, a director instructs the Scrum Master to suspend the Sprint Retrospective for the next two Sprints to recover schedule on a launch, describing it as a management decision about how the department spends its time.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Hold a shortened fifteen-minute Retrospective so the director's concern is partly accommodated.",
   "Comply, since the director has authority over how the organisation's time is used.",
   "Explain that the Retrospective is a defined event that neither the director nor the Scrum Master may remove, and work with the director on the schedule pressure that produced the request.",
   "Refuse and escalate the instruction to the director's superior."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "A compromise that concedes the principle while appearing reasonable. Timeboxes are maximums, so a short Retrospective is permitted — but shortening it in order to satisfy a request to remove it trades the event's purpose for the appearance of it.",
   "Confuses serving with acquiescing. A Scrum Master has no authority over people and real authority over the framework's integrity; the events happening and serving their purpose sits squarely in the second category.",
   "Correct. Two things are held together: the event is not removable, and the pressure behind the request is real and is the Scrum Master's business. Only doing the first is rule-keeping.",
   "The right position taken in the wrong way. Escalating before speaking to the person spends credibility, and it treats a schedule problem the director genuinely owns as a matter of authority rather than a problem to solve."
  ],
  "hard": "A is the answer that feels like professional pragmatism. It is also how events are hollowed out — not by removal, but by accommodation."
 },
 {
  "n": 13,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "A pharmacy chain formed a Scrum Team eight months ago from a department that had been project-managed for a decade. In Sprint Planning the Developers wait to be told which items to take. The Scrum Master has repeatedly encouraged them to organise the work themselves. Nothing has changed.",
  "ask": "What is the most appropriate next step?",
  "options": [
   "Determine which of boundary, purpose, capability or safety is missing, and address that specifically.",
   "Continue encouraging them; developing self-management takes time.",
   "Ask the Product Owner to allocate the items so Sprint Planning can conclude.",
   "Allow Sprint Planning to stall until the Developers act, so they experience the consequence of not deciding."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. A team that will not decide is usually a team for which deciding is unclear, unsafe, or beyond its current capability — not a team of passive people. The diagnosis determines the intervention, and each of the four requires something different.",
   "Eight months of encouragement has produced no change, which is evidence that encouragement is not the missing ingredient. Repeating an ineffective intervention is not patience.",
   "Solves the immediate stall by installing precisely the arrangement the team needs to leave behind, and moves a Developers' decision to the Product Owner.",
   "Deliberate deprivation, which fails on the capability precondition. A team that has never held the decision does not acquire the judgement by being left without help; it acquires a failed Sprint and evidence that the new way does not work."
  ],
  "hard": "B and D are the two instincts most Scrum Masters have — wait longer, or force the issue. Both treat the team's behaviour as a matter of will."
 },
 {
  "n": 14,
  "bucket": "Developing People and Teams",
  "focus": "Coaching and Mentoring",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "At an agricultural equipment manufacturer, a newly appointed Product Owner asks the Scrum Master how to decide the order of the Product Backlog for the coming quarter. They have never ordered a backlog before. The Scrum Master has ten years of product experience.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Introduce the Product Owner to a more experienced Product Owner elsewhere in the organisation for mentoring.",
   "Explain the common inputs to ordering — value, risk, dependency, cost of delay, coherence with the Product Goal — then work through applying them to this backlog together.",
   "Use open questions so the Product Owner develops their own ordering judgement.",
   "Propose an order with the reasoning, so the Product Owner has a worked example to learn from."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Not wrong, and not a substitute. It defers a service the Scrum Master owes the Product Owner directly, and it will be slower than the situation allows.",
   "Correct. The gap is knowledge first and judgement second, so the sequence is teach then coach. The Scrum Master's accountability explicitly includes helping the Product Owner find techniques for effective Product Backlog management.",
   "Coaching a person who does not yet have the raw material. Open questions build capacity where capacity exists; here the Product Owner does not know what the available considerations are, and will experience the questions as being tested.",
   "Consulting. It produces an order and no capability, and it makes the Scrum Master's judgement the reference point for a decision that belongs to the Product Owner."
  ],
  "hard": "C is the answer that sounds most like coaching and is wrong for exactly that reason. Stance follows the gap, and the gap here is knowledge."
 },
 {
  "n": 15,
  "bucket": "Developing People and Teams",
  "focus": "Conflict · Facilitation",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "At an engineering consultancy, two Developers have disagreed about a technical approach for three Sprints. It is no longer about the approach: one now reviews the other's work noticeably more slowly than anyone else's. A third Developer has quietly begun routing work away from the pair to avoid friction. Nothing has been raised in a Retrospective.",
  "ask": "Which TWO actions are most appropriate?",
  "options": [
   "Raise the pattern in the Retrospective without naming anyone, so the team can examine it.",
   "Address the third Developer's routing decision, which is what has allowed the situation to persist unseen.",
   "Refer the matter to their line manager, since review latency and work avoidance are performance issues.",
   "Meet each of the two separately before bringing them together with a structure."
  ],
  "correct": [
   1,
   3
  ],
  "rationale": [
   "The conflict has moved from positions to people, which puts it past what a group setting can repair. Anonymity will fool nobody — both will know — and exposing them publicly without their agreement tends to convert a recoverable situation into a permanent one.",
   "Correct, and the part most often missed. The routing is why nobody has had to deal with this for three Sprints. Repairing the pair without addressing the workaround leaves the mechanism that hid it intact.",
   "Premature and disproportionate. It converts an interpersonal conflict into a performance record and ends the possibility of the two resolving it. Reserve it for behaviour genuinely outside the Scrum Master's remit.",
   "Correct. Each needs to be able to say the ungenerous version to someone before they can say the generous version to each other. The joint conversation then needs an actual structure rather than goodwill."
  ],
  "hard": "A is the standard move and is wrong at this stage of escalation. B is correct and is rarely selected, because the third Developer looks like a bystander rather than a participant."
 },
 {
  "n": 16,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation",
  "shape": "Choose a different stance",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "When facilitating a Sprint Retrospective, the Scrum Master should remain neutral and avoid offering their own view of what the team should improve.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false, on two counts. First, the Scrum Master is a member of the Scrum Team and participates in the Sprint Retrospective; they are not an external facilitator with no stake. Second, genuine neutrality is rarely available to someone who has watched the team for months, and appearing neutral while steering the conversation through leading questions and selective summarising is worse than either honest alternative. The workable position is to separate the roles out loud: facilitate, say explicitly when stepping out of facilitation to offer a view, offer it, and step back — so the team can weigh it as one input rather than mistaking it for the process."
  ],
  "hard": "The statement describes what most facilitation training teaches and what most candidates believe. It is also incompatible with the Scrum Master being a member of the Scrum Team."
 },
 {
  "n": 17,
  "bucket": "Developing People and Teams",
  "focus": "Events · Self-Managing Teams",
  "shape": "Do less than the options suggest",
  "type": "single",
  "stem": "At an online education company, two Developers begin a detailed design argument during the Daily Scrum and the others disengage. On previous occasions the Scrum Master has stepped in to redirect. Today, before the Scrum Master says anything, the two Developers stop themselves, agree to continue afterwards, and the event moves on.",
  "ask": "What is the most appropriate action for the Scrum Master during the event?",
  "options": [
   "Nothing.",
   "Suggest a timebox for the offline discussion so it does not consume the rest of the day.",
   "Confirm to the group that taking the discussion offline was the right call, to reinforce the behaviour.",
   "Note the interruption so it can be examined in the Retrospective."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. The Developers did the thing the Scrum Master has been coaching toward, in their own event, without help. Any intervention at this moment — including a positive one — reinserts the Scrum Master into a self-correction that just happened without them.",
   "Adds a constraint nobody asked for to a discussion the Developers have already scoped themselves.",
   "Approving the Developers' conduct in their own event makes the Scrum Master an evaluator of it. It is well meant and it signals that the behaviour needed ratification.",
   "There is nothing to examine. The event worked, which is the outcome the Retrospective would have been aiming at."
  ],
  "hard": "Three of the four options are actions a conscientious Scrum Master would consider, and the correct answer is to do none of them. Restraint is rarely the instinct under exam conditions."
 },
 {
  "n": 18,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams · Scrum Values",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "At a law firm, Retrospectives are consistently polite and produce nothing. In individual conversations the Developers describe substantial problems. Asked why these are not raised, they explain that the Product Owner reports to the department head and that things said in the room have previously reached them.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Coach the Developers to raise their concerns despite the discomfort, since Courage is a Scrum Value.",
   "Work on what happens to information after it is raised, with the Product Owner and the department head.",
   "Hold Retrospectives without the Product Owner so the Developers can speak freely.",
   "Introduce anonymous input so the concerns surface without attribution."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Asks individuals to absorb a personal risk so that the framework functions. The Developers already know they are withholding; they are doing so for reasons that are rational given what has happened before.",
   "Correct. Safety is a precondition, and it is a property of the environment rather than of the people. The durable intervention is to change what honesty costs — which means the conversation is with the Product Owner and the department head, not with the Developers.",
   "The Product Owner is a member of the Scrum Team and the Sprint Retrospective is a Scrum Team event. Excluding them treats a trust problem by removing an accountability, and the information the Product Owner most needs is precisely what is not being said.",
   "A useful technique addressing the symptom. It may get problems named, and it leaves intact the reason people could not name them, so the team's capacity to be open does not improve."
  ],
  "hard": "D is genuinely useful and will attract candidates who have used it successfully. The item tests whether the answer treats the condition or the consequence."
 },
 {
  "n": 19,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a rail maintenance organisation, the two most experienced Developers do nearly all the talking in Sprint Planning. The others agree with whatever is proposed and rarely raise concerns. The team's forecasts have been substantially wrong for several Sprints.",
  "ask": "Which TWO changes would most directly address the situation?",
  "options": [
   "Ask the two most experienced Developers to contribute last.",
   "Extend the Sprint Planning timebox so quieter Developers have more time to contribute.",
   "Have every Developer record their own view of the work independently before any discussion begins.",
   "Ask the Product Owner to bring more detailed requirements to Sprint Planning."
  ],
  "correct": [
   0,
   2
  ],
  "rationale": [
   "Correct. Reversing the speaking order means the less experienced views enter uncontaminated by what the senior view turned out to be. Cheap, and immediately effective.",
   "Time is not the constraint. More minutes in the same dynamic produces more of the same dynamic, and quieter people do not become louder because the meeting is longer.",
   "Correct. Silent writing before discussion means everyone's assessment exists before anyone's voice dominates, which separates generating a view from advocating one. It is the most direct remedy for a room where agreement is produced by deference.",
   "Misattributes the cause. The forecasts are wrong because most of the team's knowledge is not entering the conversation, not because the items are underspecified."
  ],
  "hard": "B is superficially reasonable and is the sort of accommodation that feels considerate. The item tests whether a candidate can identify what is actually producing the silence."
 },
 {
  "n": 20,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "At an energy utility, a director regularly asks Developers directly for small changes when passing their desks, and the Developers carry them out. The Product Owner finds out at the Sprint Review. The Product Owner is two levels junior to the director.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Coach the Developers to decline any request that has not come through the Product Owner.",
   "Ask the Product Owner to speak to the director about respecting the Product Backlog.",
   "Introduce a rule that all requests are logged with the Scrum Master for triage before reaching the team.",
   "Speak with the director directly, and separately work with the Developers on where requests belong and with the Product Owner on why the front door is slow."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Asks Developers to refuse a director — a risk the Scrum Master is not taking themselves. Coaching that requires someone else to absorb the cost of a confrontation is not coaching.",
   "Sends a person two levels junior into the same confrontation, alone, on a matter of the director's own behaviour. It is likely to fail once and make the Product Owner's position worse than before.",
   "Makes the Scrum Master a gatekeeper, which is a new bottleneck and an accountability Scrum does not contain. It also leaves the Product Owner still not deciding.",
   "Correct. Three parts, and skipping any of them makes it fail: the conversation with the person who outranks the Product Owner is the Scrum Master's to have; the Developers are saying yes out of helpfulness and need to know where requests belong; and someone going around the front door is usually reporting something true about how the front door works."
  ],
  "hard": "A is what most guidance suggests, and it becomes the wrong answer the moment the person going around the Product Owner outranks everyone the Developers can safely refuse."
 },
 {
  "n": 21,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Managing Technical Risk",
  "shape": "Force a decision",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "Technical debt that the Developers want to address should be represented in the Product Backlog and ordered by the Product Owner alongside everything else.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct — the statement is true. Technical debt is a design compromise that raises the cost of future change. Repaying it is Product Backlog work that competes on value with everything else, and the Product Owner orders it, informed by the Developers about the cost of not doing so. Note carefully what this does not cover: undone work — work required by the Definition of Done and left incomplete on an item reported as Done — is not a prioritisation question at all. It is a Definition of Done violation, and no amount of ordering turns an item that fails Done into a Done item.",
   ""
  ],
  "hard": "The true statement is easy to accept and the value of the item is in the boundary. Candidates who have learned that quality is never negotiable sometimes reject this, conflating debt with undone work."
 },
 {
  "n": 22,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Done · Managing Technical Risk",
  "shape": "Hold a line",
  "type": "single",
  "stem": "A tax filing product faces a statutory submission deadline that cannot move. Two weeks out, the Developers propose omitting the accessibility checks required by the Definition of Done for three items and recording them as follow-up work. The Product Owner agrees. Accessibility is a legal duty for this organisation.",
  "ask": "What is the most appropriate response from the Scrum Master?",
  "options": [
   "Escalate immediately to the organisation's legal function.",
   "Make clear that items not meeting the Definition of Done are not Done and cannot be presented as complete, and help the Scrum Team renegotiate scope instead.",
   "Support the decision, since the Product Owner is accountable for value and has weighed the trade-off.",
   "Accept it on the condition that the follow-up items are ordered at the top of the next Sprint."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Disproportionate as a first move and skips the Scrum Team entirely. It may become appropriate if the team proceeds regardless, but reaching for it first spends credibility and removes the team's chance to resolve it.",
   "Correct. When the goal is at risk the negotiable variable is scope, never quality. Three items delivered and Done is a defensible outcome; three items delivered and not Done is a false report.",
   "Invokes a real accountability that does not extend this far. The Product Owner decides what is built and in what order; they do not decide that work failing the Definition of Done counts as Done.",
   "The follow-up item anti-pattern with a reassuring condition attached. The items are still reported as complete, still counted as progress, and the statutory exposure is still carried without anyone deciding to carry it."
  ],
  "hard": "Every option except B is something a reasonable person does under deadline pressure, and C cites a genuine accountability. The deadline being real is what makes the item difficult."
 },
 {
  "n": 23,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Managing Technical Risk",
  "shape": "Force a decision",
  "type": "single",
  "stem": "At a fleet telematics company, the Developers report that the data ingestion service has no back-pressure handling. The Product Owner does not understand what this implies and has not ordered any related work. Ingestion volume is growing about eight per cent a month.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Explain to the Product Owner that technical decisions belong to the Developers and should be trusted.",
   "Ask the Developers to put the work into the Product Backlog themselves.",
   "Order the work into the Product Backlog given the growth rate and the clear trajectory.",
   "Help the Developers express the risk as what will fail, who it affects, and on what timescale, so the Product Owner can order it against everything else."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "A real principle applied to the wrong decision. The Developers decide how the work is done; what work is done and in what order is the Product Owner's, and they cannot exercise that without understanding the option.",
   "Sounds like self-management and leaves the actual problem untouched. The Product Owner still cannot weigh an item they do not understand, and adding it to the backlog without translation simply moves the incomprehension somewhere else.",
   "Takes the Product Owner's decision. The trajectory being obvious to the Scrum Master does not transfer the accountability.",
   "Correct. Technical risk goes unaddressed far more often because it was never translated than because anyone refused it. Value, cost and trajectory are the terms a Product Owner orders in, and producing them requires no technical expertise from the Scrum Master — only refusing an answer that makes sense to engineers alone."
  ],
  "hard": "B is attractive because it appears to respect the Developers' ownership. The item tests whether the Scrum Master recognises translation as their own work rather than someone else's."
 },
 {
  "n": 24,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management · Stakeholders",
  "shape": "Sequence correctly",
  "type": "multi",
  "stem": "A public library service has a Product Owner who maintains the Product Backlog well and is available to the Developers. Each month they present a proposed order to a steering group, which routinely amends it. Asked whether they can decide the order, the Product Owner says: “In theory. In practice the group decides and I do the work.”",
  "ask": "Which TWO are the most appropriate first steps?",
  "options": [
   "Work with the Product Owner to change what the group is asked for — evidence against goals rather than a sequence to approve.",
   "Understand what the steering group is accountable for and what problem it solves by amending the order.",
   "Coach the Product Owner to hold their proposed ordering at the next steering group meeting.",
   "Tell the steering group that Scrum requires the organisation to respect the Product Owner's decisions."
  ],
  "correct": [
   0,
   1
  ],
  "rationale": [
   "Correct. A body asked to approve a sequence will amend the sequence, because that is what approving means. Asked instead whether the product is achieving what it was funded to achieve, it tends to ask better questions and intervene less.",
   "Correct, and first. The group is almost certainly not behaving badly — it was probably constituted to approve scope and has a real accountability, often financial. Until that is understood, any intervention is an attempt to remove a load-bearing wall.",
   "Sets the Product Owner up to lose. Asserting authority into a governance body that outranks them, with nothing about that body changed, asks them to absorb a confrontation on the Scrum Master's behalf. They will lose once and not try again.",
   "Correct in substance and wrong as an opening move. Asserting a framework requirement to a governance body that has not been understood, on behalf of a Product Owner who has not been prepared, is a confrontation rather than a change."
  ],
  "hard": "All four options are things that might eventually happen. The item is entirely about order, and C is the one most candidates reach for first."
 },
 {
  "n": 25,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers",
  "shape": "Build a missing precondition",
  "type": "single",
  "stem": "A veterinary practice software team has never observed a user. All insight reaches the Developers through the Product Owner, a former practice manager who is well regarded and accurate. The Developers make small interpretive decisions several times a Sprint with nobody available to ask.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Nothing; the Product Owner represents the users and is qualified to do so.",
   "Ask the Product Owner to write more detailed acceptance criteria so interpretation is unnecessary.",
   "Invite users to the Daily Scrum so the Developers can ask questions as they arise.",
   "Arrange for Developers to observe real users, without displacing the Product Owner's accountability for value."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "The Product Owner's competence is not in question, and it is not the point. Insight arriving second-hand is interpreted and stripped of the detail that would have changed a decision, and the Developers are making dozens of small choices with nobody to ask.",
   "The specification reflex. It attempts to eliminate judgement rather than inform it, produces documents that go stale, and puts more load on the Product Owner as the sole channel.",
   "The Daily Scrum is a fifteen-minute event for the Developers to inspect progress and re-plan. Bringing users into it changes its purpose and makes it a forum for something else.",
   "Correct. Direct exposure improves the quality of the decisions Developers make when no one is available, and it takes nothing away from the Product Owner's accountability for maximising value. A morning's observation is usually enough to change how a team thinks."
  ],
  "hard": "A is the most defensible wrong answer in the exam, because a competent Product Owner really is doing their job. The item tests whether a candidate can see what is lost regardless."
 },
 {
  "n": 26,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "At a port operator, a Scrum Team cannot release without approval from a change advisory board that meets fortnightly. The Scrum Master is told the board is required by the industry regulator. On reading the regulation, the requirement is for a documented approval record — it says nothing about a board or a meeting.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Accept the constraint; regulatory requirements are not open to negotiation.",
   "Make the distinction visible — the regulator requires a record, the board is how this organisation chose to produce one — and facilitate a conversation about alternatives that satisfy the requirement.",
   "Write to the regulator seeking clarification of the requirement.",
   "Have the team release to a staging environment each Sprint so the board is not on the critical path."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Accepting a habit as though it were a law. The regulation is a genuine constraint; the fortnightly board is an implementation choice, and the two are being treated as the same thing by everyone including the Scrum Master's informant.",
   "Correct. Separating what is externally binding from what the organisation chose is the core of reading an organisational system. Note that the answer is not to remove the approval — the record is required — but to open the question of how it is produced.",
   "Slow, and it escalates outside the organisation a question that has not yet been asked inside it. The regulation has already been read; the issue is what the organisation built on top of it.",
   "A workaround that leaves the Increment undeliverable and the constraint intact, while creating the appearance of progress. It also quietly redefines what the team means by releasable."
  ],
  "hard": "A is what almost everyone in the organisation already believes, including people who have never read the regulation. The item tests whether the candidate distinguishes constraint from habit."
 },
 {
  "n": 27,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "At a consumer electronics company, Developers' annual objectives include individual story points delivered. Team members have stopped helping one another. The engineering manager who sets the objectives says he needs something defensible for the human resources moderation process and that nobody has offered him an alternative.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Report to human resources that the objective-setting process conflicts with Scrum.",
   "Coach the Developers to prioritise the Sprint Goal over their individual objectives.",
   "Raise the objectives with the Product Owner as an impediment to the Sprint Goal.",
   "Offer to help the engineering manager build objectives he can defend in moderation that do not rely on individual output."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Goes over the head of someone who has explicitly asked for help, on a process he did not design. It converts a solvable problem into a dispute and makes the next conversation harder.",
   "Asks individuals to deprioritise the measures their pay progression depends on. That is not a values conversation; it is a request that they take a personal financial risk so the framework works.",
   "The Product Owner has no authority over how Developers are appraised and no route to change it. It makes the impediment visible to someone who cannot act on it.",
   "Correct. The manager has already said what he needs and that nobody has supplied it, which is an invitation. It is also the cheapest available route: the person who owns the measure is willing, and the intervention is at the measure rather than at the people responding rationally to it."
  ],
  "hard": "B is the most common answer and repeats the error the situation is built on — asking the people with the least power to absorb the cost of a system nobody has offered to change."
 },
 {
  "n": 28,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "At a satellite imagery company, a separate platform group owns the data pipeline that every Scrum Team depends on. It does not work in Sprints, and integration regularly fails late. A manager proposes formalising the group as an integration function that all Scrum Teams submit work to.",
  "ask": "What is the most appropriate response from the Scrum Master?",
  "options": [
   "Ask each Scrum Team to absorb the part of the pipeline it uses most heavily.",
   "Support the proposal, since the accountability for integration would finally have a clear owner.",
   "Make the current dependency and what it costs transparent first, and let that evidence shape what the integration accountability should be.",
   "Oppose the proposal and put the case for dissolving the platform group into the Scrum Teams."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "A technical reorganisation proposed by someone who is not accountable for the architecture, and it is unlikely to survive contact with whoever is.",
   "Formalises a component team and makes the existing dependency permanent. A queue forms, the Scrum Teams stop owning integration, and feedback stretches to the length of the gate — and it is very hard to reverse once it has a name and a headcount.",
   "Correct. Evidence about what integration actually requires is what makes the later conversation winnable rather than theoretical, and gathering it is cheap and reversible. When several actions are all defensible, the one that makes the others possible goes first.",
   "The right destination as an opening move. It asks the manager to abandon a sensible-looking proposal in favour of a restructure, on the authority of a framework he has no reason to care about, before anyone has evidence his version would fail."
  ],
  "hard": "D is the answer a candidate who has understood component teams will choose, and it is right about the destination and wrong about the sequence."
 },
 {
  "n": 29,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a supermarket logistics division, Developers are allocated to Scrum Teams by a central resourcing function and reassigned between teams each quarter according to forecast demand.",
  "ask": "Which of the following are likely consequences? Select all that apply.",
  "options": [
   "Cross-functionality is harder to build, because skill gaps are filled by reallocation rather than learning.",
   "The Product Owner becomes accountable for the Developers' capability.",
   "Team members have less reason to invest in improving how the team works.",
   "Forecasting becomes less reliable as team composition changes."
  ],
  "correct": [
   0,
   2,
   3
  ],
  "rationale": [
   "Correct. A team that acquires a missing skill by requisition never develops it, so the dependency is permanent and cross-functionality never arrives.",
   "Incorrect. Nothing about reallocation moves capability accountability to the Product Owner, who is accountable for maximising the value of the product. This is an organisational design problem, and it belongs to whoever owns the resourcing function.",
   "Correct. Improvement is an investment in a group you expect to be part of. Where membership resets quarterly, the payback period exceeds the tenure.",
   "Correct. Forecasts rest on a team's accumulated understanding of its own work and each other. Changing the composition resets that, and the effect is invisible in any report."
  ],
  "hard": "Three correct options and one that misplaces an accountability. Candidates who have learned that multiple-response items usually have two answers will under-select."
 },
 {
  "n": 30,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "A Scrum Master newly appointed at an aviation maintenance business identifies four problems in their first month: the Daily Scrum has become a status report to a manager who attends; the Definition of Done excludes integration, which a separate group performs afterwards; Developers report to four different functional managers; and work is funded annually as projects.",
  "ask": "Which should the Scrum Master address first?",
  "options": [
   "The Daily Scrum, since it is entirely within the Scrum Team's gift and can change this Sprint.",
   "The annual project funding model, since it is the root cause from which the others follow.",
   "The functional reporting structure, since divided reporting undermines team accountability.",
   "The Definition of Done, since it requires agreement from the separate integration group and will take longest to arrange."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. It requires nobody's permission outside the Scrum Team, it can change immediately, and it produces the first evidence that things here can be different. Calibrating ambition to timescale is not timidity; it is what makes the later conversations possible.",
   "Probably the correct root cause and the furthest beyond a new Scrum Master's reach. Funding models change when someone with authority decides to change them; the Scrum Master's role is to supply evidence and framing, not to lead it — and they have no evidence yet.",
   "A year's work requiring a sponsor, attempted in month one by someone with no standing and no track record in the organisation.",
   "Correct that it matters and correct that it is slow, which is the reason it is not first. Its own answer explains why: it needs another group's agreement, and a new Scrum Master has nothing yet with which to ask."
  ],
  "hard": "B is analytically the best diagnosis and the worst first action, which is the trap. D even states its own disqualifying condition, and candidates still select it because quality feels urgent."
 }
];
