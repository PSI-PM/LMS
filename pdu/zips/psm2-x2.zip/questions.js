var META = {"minutes": 90, "pass_mark": 85, "pass_count": 26};
var QUESTIONS = [
 {
  "n": 1,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Events · Done",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "At a hospital trust, the Sprint Review has become a session in which a clinical governance lead approves or rejects each completed item. Rejected items are reworked the following Sprint. Attendance is otherwise good and the Product Owner finds the scrutiny valuable.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Work with the Scrum Team and the governance lead to bring the clinical standard into the Definition of Done, so the Increment satisfies it before the Sprint Review rather than being judged at it.",
   "Move the approval into a separate meeting held after the Sprint Review.",
   "Leave the arrangement alone; stakeholders are engaged and the Product Owner values the input.",
   "Ask the governance lead to send written feedback afterwards so the Sprint Review stays collaborative."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. If a clinical standard determines whether work is releasable, it belongs in the Definition of Done where the Developers can meet it during the Sprint. The Sprint Review then inspects a genuinely Done Increment and adapts the Product Backlog, which is what it is for.",
   "Preserves the gate and adds a meeting. The rework cycle is unchanged and the Increment is still not Done when it is presented.",
   "Engagement is not the problem. The Sprint Review has become an approval gate, which means work is being reported as complete and then found not to be — so the Increment is not what it claims and the Sprint Review is inspecting something unfinished.",
   "Removes the conversation and keeps the gate. Written feedback after the event is slower, less rich, and still arrives after the work was declared done."
  ],
  "hard": "D and B are both reasonable-sounding process fixes, and both leave a quality standard living outside the Definition of Done — which is the actual fault."
 },
 {
  "n": 2,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "The Sprint · Done",
  "shape": "Hold a line",
  "type": "single",
  "stem": "A car sharing company releases quarterly. The Developers propose that every fourth Sprint become a stabilisation Sprint with no new features, used to fix defects and finish integration work deferred from the previous three.",
  "ask": "How should the Scrum Master respond?",
  "options": [
   "Help the team see that deferring integration and defects for three Sprints means those Sprints did not produce a Done Increment, and address why the Definition of Done is not being met each Sprint.",
   "Propose lengthening the Sprint instead, so integration work fits inside one.",
   "Support it provided the Product Owner orders the stabilisation work in the Product Backlog.",
   "Support it; the Developers are self-managing and this is how they have chosen to organise their work."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. A stabilisation Sprint is a symptom rather than a practice: it exists because the Definition of Done is not being met. The useful conversation is about what is being deferred, why, and what would have to change for each Sprint to end with something usable.",
   "A longer Sprint conceals the same problem for longer and slows feedback. It may form part of an eventual answer; it is not the diagnosis.",
   "Ordering the work does not repair it. The problem is not that the stabilisation work is invisible — it is that three previous Increments were reported as Done and were not.",
   "Self-management operates within the framework rather than outside it. An arrangement in which three Sprints in four produce nothing releasable is not a decision within the Developers' gift."
  ],
  "hard": "D invokes self-management, which is a real principle, and C appears to apply transparency. Neither touches the reason the Increment is not Done."
 },
 {
  "n": 3,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Product Backlog refinement",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "A brewery's logistics team refines its Product Backlog in a mandatory two-hour meeting every Wednesday, chaired by the Scrum Master. Items may not be selected in Sprint Planning until they satisfy a Definition of Ready checklist. The Developers say Sprint Planning is smoother; the Product Owner says items now wait two or three Sprints before they can be taken.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Ask the Product Owner to prepare items further in advance so they clear the checklist sooner.",
   "Hand the refinement conversation back to the Scrum Team, treat refinement as the ongoing activity it is rather than a chaired event, and examine whether the Definition of Ready is restricting the flow of value.",
   "Reduce the checklist to the items the Developers say they genuinely need.",
   "Keep the arrangement; smoother Sprint Planning is evidence that it works."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Accepts the gate and asks the Product Owner to work around it, which increases her load and leaves the delay in place.",
   "Correct. Refinement is an ongoing activity with no timebox and is not an event the Scrum Master chairs. A Definition of Ready is a complementary practice rather than part of Scrum, and it becomes an anti-pattern at exactly the point where it prevents items being selected.",
   "A partial improvement that leaves both faults standing: the Scrum Master still owns a conversation belonging to the Scrum Team, and a gate still sits between refined work and the Sprint.",
   "The smoothness is bought with a two-to-three Sprint delay on every item, which the Product Owner is reporting. One party's convenience is not evidence that the arrangement serves the product."
  ],
  "hard": "C is the pragmatic middle and will attract candidates who have spotted the Definition of Ready problem but not the ownership problem sitting behind it."
 },
 {
  "n": 4,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Product Goal · Artifacts",
  "shape": "Hold a line",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "A Scrum Team may pursue more than one Product Goal at a time, provided each is clearly communicated and the Product Backlog is ordered accordingly.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. The Product Goal is the single long-term objective for the Scrum Team, and the team must fulfil or abandon one objective before taking on the next. Its whole purpose is to give every ordering decision something to be right or wrong about; two concurrent goals restore precisely the ambiguity it exists to remove. Neither of the safeguards offered helps: communicating both clearly does not make them arbitrate between each other, and a backlog ordered against two objectives is a backlog whose order cannot be defended."
  ],
  "hard": "The statement attaches two plausible safeguards — clear communication and a correspondingly ordered backlog — and neither addresses the reason a single objective exists."
 },
 {
  "n": 5,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Artifacts · Done",
  "shape": "Hold a line",
  "type": "multi",
  "stem": "A team building an online census response system deploys to production several times a week.",
  "ask": "Which of the following are true of the Increment? Select all that apply.",
  "options": [
   "More than one Increment may be created within a single Sprint.",
   "An Increment may be delivered to stakeholders before the Sprint ends.",
   "The Sprint Review is the point at which an Increment is released.",
   "Work must meet the Definition of Done to form part of the Increment."
  ],
  "correct": [
   0,
   1,
   3
  ],
  "rationale": [
   "Correct. Multiple Increments may be created within a Sprint, and at least one must exist by the Sprint Review.",
   "Correct. Delivery is not held back for the Sprint Review, and releasing earlier is encouraged rather than merely tolerated.",
   "Incorrect. The Sprint Review is where the Increment is inspected and the Product Backlog adapted. Releasing is a separate decision, and tying it to the Sprint Review delays value for no reason the framework requires.",
   "Correct. Work that does not meet the Definition of Done is not part of the Increment and returns to the Product Backlog."
  ],
  "hard": "C describes how most teams actually operate, and it is contradicted by the framework rather than merely discouraged by it."
 },
 {
  "n": 6,
  "bucket": "Understanding and Applying the Scrum Framework",
  "focus": "Empiricism · Artifacts",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "The Product Owner at a textile manufacturer keeps the shared Product Backlog short and tidy. She also maintains a private spreadsheet of what she calls the real priorities, which she uses to decide what to bring to Sprint Planning. The Developers have noticed items arriving in Sprint Planning that were never in the Product Backlog.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Ask the Product Owner to stop maintaining a separate list.",
   "Explore with the Product Owner what the private list does for her that the Product Backlog does not, and work from there toward a single transparent backlog.",
   "Advise the Developers to decline items that were not in the Product Backlog before Sprint Planning.",
   "Ask the Product Owner to publish the spreadsheet alongside the Product Backlog."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "An instruction with no diagnosis. The private list exists because it is doing something for her, and removing it without knowing what will produce a less visible version of the same behaviour.",
   "Correct. Transparency of the Product Backlog is not optional, and the durable route to it runs through understanding why the workaround exists — usually that the shared backlog is read by people whose reactions she is managing.",
   "Asks the Developers to police the Product Owner, and converts a transparency problem into a confrontation at the least useful moment.",
   "Two published artifacts instead of one. Transparency is not achieved by publishing more; the Product Backlog is meant to be the single source of work for the Scrum Team."
  ],
  "hard": "D looks like a transparency answer and is the option most candidates who have correctly spotted the problem will choose."
 },
 {
  "n": 7,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Force a decision",
  "type": "single",
  "stem": "A waste management company has one Scrum Master supporting five Scrum Teams. She attends each team's Sprint Planning and Sprint Review, reaches few Daily Scrums, and has no time for anything beyond the events. The teams describe her as helpful but stretched. A director asks her to take a sixth team.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Accept; the accountability does not require attending every event.",
   "Decline, on the grounds that one Scrum Master cannot serve six Scrum Teams.",
   "Accept, and ask each team to nominate someone to facilitate in her absence.",
   "Make visible what is already not happening at five teams — coaching, organisational impediment removal, building the teams' own capability — and let the director decide with that in front of him."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "True that attending every event is not required, and it answers a different question. What is missing at five teams is not attendance; it is everything the accountability consists of beyond running the events.",
   "Scrum sets no number, and a flat refusal gives the director nothing to decide with. It also invites the entirely reasonable reply that other organisations manage it.",
   "Distributes facilitation, which may well be healthy, while accepting the premise that the accountability consists of running events.",
   "Correct. The staffing decision is the director's and is currently being made without information. Naming what has been squeezed out converts an opinion about workload into a choice about what the organisation is actually buying."
  ],
  "hard": "C is appealing because building the teams' own facilitation capability is genuinely good practice. It is the right activity offered as a way of accepting the wrong premise."
 },
 {
  "n": 8,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A department head at a dental practice group asks the Scrum Master for a short written assessment of each Developer's contribution over the last quarter, to inform pay reviews. He explains that he has no other visibility of their work and that without her input the reviews will rest on nothing.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Provide the assessments; she has the clearest view of the team and the alternative is worse.",
   "Provide the assessments, but share each one with the Developer concerned first so nothing is said behind anyone's back.",
   "Decline, explaining that assessing individuals is not part of the accountability and would damage the team's willingness to be open with her.",
   "Decline to assess individuals, and offer instead to help him see the team's work directly — including attending Sprint Reviews — so that his reviews rest on something real."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Makes the Scrum Master an evaluator of the people whose openness the accountability depends on. Every Retrospective afterwards is a conversation with the person who writes your appraisal.",
   "Openness about an activity that should not be happening. Being transparent about crossing a boundary does not uncross it.",
   "Correct about the boundary and leaves the department head exactly where he started — which is the situation that produced the request. A refusal without an alternative usually means the assessment is made anyway, less well.",
   "Correct. Both halves matter: the boundary holds, and the real problem underneath it — a manager with no visibility of the work — is treated as a problem worth solving rather than as someone else's."
  ],
  "hard": "C is not wrong, only incomplete, which is the discriminator. B adds a fairness safeguard that is irrelevant to whether the assessment should exist at all."
 },
 {
  "n": 9,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability · Events",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "A Scrum Master joins a film post-production house where the team calls its two-week iterations Sprints, holds all five events, and delivers reliably. Closer observation shows the Sprint Goal is written after items are selected, the Retrospective produces no change, and the Product Owner is a delivery manager who assigns work to individuals. Stakeholders are satisfied.",
  "ask": "What should the Scrum Master do first?",
  "options": [
   "Raise the Product Owner problem, since work being assigned to individuals is the most serious of the three.",
   "Start with the Retrospective, since it is the event through which the team could address everything else.",
   "Observe for another Sprint before acting, since stakeholders are satisfied and nothing is failing.",
   "Explain to the team which parts of their practice are not Scrum, so everyone shares an accurate picture."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "The most serious problem and the hardest, requiring standing with a person who currently feels none of the team's discomfort. It is where this ends rather than where it starts.",
   "Correct. The Retrospective is the mechanism by which a team improves anything else, it sits entirely within the team's own gift, and repairing it first means the other two problems can be raised by the team rather than by the newcomer. When several things are wrong, start with the one that makes the rest addressable.",
   "Passivity dressed as empiricism. The Scrum Master has already observed enough to name three specific faults; another Sprint adds nothing but delay.",
   "Accurate and premature. A new Scrum Master telling a delivering team that it is doing Scrum wrongly spends credibility that has not yet been earned, and invites the reasonable reply that things are going fine."
  ],
  "hard": "A is analytically correct about severity, which is precisely the trap. Sequencing items reward the action that makes the others possible, not the one that matters most in the abstract."
 },
 {
  "n": 10,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Restore an accountability",
  "type": "multi",
  "stem": "A newly formed Scrum Team at a marine navigation company asks its Scrum Master what she is actually accountable for.",
  "ask": "Which of the following belong to the Scrum Master accountability? Select all that apply.",
  "options": [
   "Helping the organisation understand and enact Scrum.",
   "The Scrum Team's effectiveness.",
   "Establishing Scrum as defined in the Scrum Guide.",
   "Ensuring the Product Backlog is ordered so that value is maximised."
  ],
  "correct": [
   0,
   1,
   2
  ],
  "rationale": [
   "Correct. Service to the organisation is part of the accountability: leading and coaching its Scrum adoption, and removing barriers between stakeholders and Scrum Teams.",
   "Correct. The accountability explicitly covers the Scrum Team's effectiveness, pursued by enabling the team to improve its practices within the framework.",
   "Correct. The Scrum Master is accountable for establishing Scrum as defined in the Scrum Guide, and for helping everyone understand its theory and practice.",
   "Incorrect. Ordering the Product Backlog is the Product Owner's accountability. The Scrum Master helps the Product Owner find techniques for effective Product Backlog management — which is a different thing from owning the order."
  ],
  "hard": "D is the option most often selected, because helping with Product Backlog management genuinely is part of the accountability and the line between helping and owning is easy to lose."
 },
 {
  "n": 11,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Team accountabilities",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "The Product Owner at a probation service begins six months of parental leave shortly. The department head asks the Scrum Master to hold the Product Owner accountability during the absence, since she knows the Product Backlog well and nobody else is available.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Accept, provided one of the Developers takes on the Scrum Master accountability for the period.",
   "Accept for the duration; the alternative is a Scrum Team with no Product Owner at all.",
   "Decline, and help the department head identify and prepare someone who can hold the accountability with real decision authority.",
   "Split it: hold the Product Backlog administratively while the department head makes the value decisions."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Solves the wrong half. Moving the Scrum Master accountability elsewhere does not make it appropriate for one person to decide product value while coaching the team that builds it.",
   "One person holding both accountabilities removes the tension between them that makes each work. The person coaching the team on self-management would also be deciding what they build.",
   "Correct. The accountability needs someone with genuine authority over value and the Product Backlog, and six months' notice is ample time to find and prepare them. Helping the organisation do so is service to the organisation, which is squarely part of the job.",
   "A textbook proxy Product Owner: someone maintaining a backlog on behalf of a decision-maker who is not in the room. It is the arrangement to avoid, offered as a solution."
  ],
  "hard": "D sounds like a careful compromise and is a precise description of the proxy Product Owner anti-pattern."
 },
 {
  "n": 12,
  "bucket": "Scrum Master Accountability and Service",
  "focus": "Scrum Master accountability",
  "shape": "Withdraw or hand over",
  "type": "multi",
  "stem": "At an art auction house, the Scrum Master writes the Sprint Report circulated to stakeholders, books and runs all five events, maintains the team's board, and chases external dependencies. The Developers describe her as indispensable. Sprint Goals are consistently met.",
  "ask": "Which TWO observations are most relevant?",
  "options": [
   "The Sprint Report is a Product Owner responsibility that has been taken on by the wrong person.",
   "Her contribution should be included in the Developers' capacity planning.",
   "The Developers are not building the capability to run their own events or maintain their own board.",
   "None of the listed activities is the work the accountability actually consists of."
  ],
  "correct": [
   2,
   3
  ],
  "rationale": [
   "Incorrect. Scrum defines no Sprint Report. Transparency for stakeholders comes from a Done Increment inspected at the Sprint Review, so the question is not who should write the report but why one is needed at all.",
   "Incorrect. Planning capacity around the Scrum Master would formalise the dependency rather than address it, and the Scrum Master is not a Developer contributing to the Sprint Backlog.",
   "Correct. Every activity listed is one the Developers could hold, and each one they do not hold is capability that will not exist the week she is away.",
   "Correct. The list is administration. None of it is coaching, none of it addresses an organisational impediment, and the time it consumes is the accountability's real work."
  ],
  "hard": "A contains a genuine observation — the report is a substitute for transparency — attached to a false claim about whose responsibility it is."
 },
 {
  "n": 13,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams · Conflict",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "One Developer at a wind farm operator contributes noticeably less than the others, misses Daily Scrums, and has twice left a Sprint Backlog item untouched for a week. The other Developers have begun quietly working around him. Nothing has been raised in a Retrospective.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Raise the individual's performance with his line manager, who is accountable for it.",
   "Raise it in the next Retrospective so the team can address it openly.",
   "Speak with the Developer privately to understand what is happening, and separately help the Developers see that working around a colleague is a decision they are making.",
   "Ask the Product Owner to avoid selecting items that depend on that Developer until the situation improves."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "The Scrum Master is not accountable for individual performance and does not yet have the conversation on which any later step depends. It may eventually be appropriate; taken first, it ends the possibility of the team handling this itself.",
   "Naming an individual's performance in a Retrospective without having spoken to him first is an ambush, and the team's willingness to be open in that event will not survive it.",
   "Correct. Two things are happening. Something is going on with one person, which deserves a private conversation before a public one. And the Developers have chosen avoidance, which is theirs to own. Both need addressing and neither substitutes for the other.",
   "Designs the team's work around the problem, which is what the Developers are already doing informally. It makes the avoidance official and removes the last pressure to resolve it."
  ],
  "hard": "B looks like the transparent option and is the one most candidates choose. Sequence decides it: the private conversation comes before the public one."
 },
 {
  "n": 14,
  "bucket": "Developing People and Teams",
  "focus": "Leadership Styles",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A Scrum Master supports two teams at a school district. One formed three weeks ago and has never worked this way; the other has been together four years and runs its own events well. She uses the same approach with both — proposing an agenda for every event, suggesting techniques, and summarising outcomes.",
  "ask": "What is the most appropriate adjustment?",
  "options": [
   "Continue with both; consistency is what makes the practice credible.",
   "Keep the structure with the new team and withdraw deliberately from the established one, handing over specific activities while staying available.",
   "Withdraw from the new team so that it learns to self-manage from the start.",
   "Reduce her involvement with both, since the aim is always for teams to need less facilitation."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "The same quantity of structure is support for one team and interference for the other. Consistency of approach is not a virtue when the two situations differ this much.",
   "Correct. Leadership style follows what a team can currently hold, and the trajectory runs from more directive toward genuinely delegated. Reading where a team actually is, rather than where the framework's ideal sits, is the skill being tested.",
   "Deprivation as a teaching method. Capability is a precondition for self-management rather than an outcome of removing help.",
   "Right direction applied indiscriminately. A three-week-old team that has never worked this way needs the scaffolding, and removing it produces a failure the organisation will read as evidence that the approach does not work."
  ],
  "hard": "D and C both sound like respect for self-management, and both ignore that a three-week-old team is missing a precondition rather than the will."
 },
 {
  "n": 15,
  "bucket": "Developing People and Teams",
  "focus": "Coaching and Mentoring",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A Developer at a credit union tells the Scrum Master that she wants to become a Scrum Master herself and asks how to start. She is capable and well regarded, and has never facilitated anything.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Use open questions to help her work out her own development path.",
   "Share how the Scrum Master's own path went and what she would do differently, then agree something concrete for the Developer to try.",
   "Suggest she raise it with her line manager, since career development sits outside the Scrum Master accountability.",
   "Recommend a certification and a reading list."
  ],
  "correct": [
   1
  ],
  "rationale": [
   "Coaching where mentoring was asked for. She has explicitly asked someone with the experience how to start, and reflecting the question back withholds the thing she came for.",
   "Correct. Mentoring is offering your own experience to someone facing what you have faced, and the second half — agreeing something concrete to try — is what stops it becoming an anecdote. Facilitating one Retrospective with support is worth more than any reading.",
   "A boundary that does not exist. Developing people is part of what a Scrum Master does, and the request came from a member of her own Scrum Team.",
   "Teaching where mentoring was needed, and it substitutes credentials for practice. She has never facilitated anything, and a certificate will not change that."
  ],
  "hard": "A is the reflexive stance and D is the most common real-world answer. The item tests whether the candidate hears what was actually asked for."
 },
 {
  "n": 16,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation",
  "shape": "Build a missing precondition",
  "type": "multi",
  "stem": "A cold chain logistics team has spent two Retrospectives unable to agree how to handle interruptions from a support rota. Positions are entrenched, everyone has spoken, and the discussion now repeats itself.",
  "ask": "Which TWO approaches are most likely to help?",
  "options": [
   "Escalate to the manager who owns the support rota.",
   "Ask the Product Owner to decide, since the interruptions put the Sprint Goal at risk.",
   "Name the specific decision that must be made, and timebox it visibly.",
   "Have the team design a small reversible experiment to run for one Sprint, rather than settling the question in principle."
  ],
  "correct": [
   2,
   3
  ],
  "rationale": [
   "May eventually be necessary and is not facilitation. It also concedes that the team cannot resolve something that sits within its own gift.",
   "The Product Owner does not decide how the Developers organise their work, and handing them the question removes a decision the team is capable of making.",
   "Correct. A conversation that circles usually means the group is unclear what it is deciding rather than that it disagrees. Naming the decision and bounding the time turns a debate into a choice.",
   "Correct. Entrenchment usually reflects the cost of being wrong. An experiment bounded to one Sprint lowers that cost enough for people to stop defending positions, and produces evidence that two Retrospectives of argument have not."
  ],
  "hard": "A attracts because the support rota genuinely is an organisational impediment. The question asks what would help the team reach a decision, not what would remove the interruptions."
 },
 {
  "n": 17,
  "bucket": "Developing People and Teams",
  "focus": "Events · Scrum Team",
  "shape": "Restore an accountability",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "Because the Developers are accountable for the Sprint Backlog, they may set the Sprint Goal without the Product Owner's involvement.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. The Sprint Goal is created during Sprint Planning through the collaborative work of the whole Scrum Team, and then added to the Sprint Backlog. Sprint Planning opens with the Product Owner proposing how the product could increase its value in the coming Sprint, and the goal is crafted from that conversation. Both parts of the premise are true — the Sprint Backlog is by and for the Developers, and the Sprint Goal is a commitment by the Developers — but a commitment being theirs does not make the objective theirs alone to define, and a Sprint Goal set without the Product Owner has no connection to the Product Goal it is meant to serve."
  ],
  "hard": "The premise is accurate and the conclusion drawn from it is not, which is the most reliable way to build a false statement that reads as true."
 },
 {
  "n": 18,
  "bucket": "Developing People and Teams",
  "focus": "Facilitation · Self-Managing Teams",
  "shape": "Choose a different stance",
  "type": "multi",
  "stem": "A translation company's Scrum Team works across three time zones with a two-hour overlap. Events run in that window by video and are dominated by the two people sharing an office, who talk over one another and finish each other's points. Remote members contribute in the chat, which nobody reads aloud.",
  "ask": "Which TWO actions are most appropriate for the Scrum Master?",
  "options": [
   "Ask the two colocated Developers to join from separate desks so that everyone is equally remote.",
   "Help the Developers examine what is happening, choose changes themselves, and try them.",
   "Raise with management that the team's distribution is an impediment to it functioning.",
   "Introduce the collaboration tools that have worked for other teams in the organisation."
  ],
  "correct": [
   1,
   2
  ],
  "rationale": [
   "A genuinely good technique, chosen by the Scrum Master rather than by the team. If the Developers arrive at it themselves it will hold; imposed, it treats one symptom and teaches them to wait for the next suggestion.",
   "Correct. The Developers live the dynamic and must sustain whatever changes. Helping them examine it and choose is the facilitative stance this situation calls for, and it is the only route by which the change outlasts the Scrum Master's attention.",
   "Correct. A two-hour overlap across three time zones is a structural constraint the Scrum Team cannot resolve for itself, and making it visible to the people who decided the team's distribution is service to the organisation.",
   "Consulting where facilitation was needed. It also assumes the problem is tooling, when what is described is a dynamic that no tool resolves."
  ],
  "hard": "A is a good idea and is the answer a Scrum Master reaches for when they happen to know a technique. The item tests whether the technique is offered to the team or imposed on it."
 },
 {
  "n": 19,
  "bucket": "Developing People and Teams",
  "focus": "Self-Managing Teams",
  "shape": "Do less than the options suggest",
  "type": "single",
  "stem": "Midway through a Sprint the Developers at an aquaculture company disagree about whether to fix a defect now or after the Sprint Goal is secured. They ask the Scrum Master to decide, saying she has the clearest view and they are wasting time arguing.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Decide, since the team has asked and the delay itself now threatens the Sprint Goal.",
   "Refer the decision to the Product Owner, since defect priority affects the product.",
   "Decline to decide, and help them identify what each of them would need to know in order to choose.",
   "Suggest they bring the question to the next Retrospective."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "The fastest route to a decision and the surest way to be asked again. A team that has handed one decision to the Scrum Master under time pressure will hand over the next.",
   "How the work is done within the Sprint belongs to the Developers. The Product Owner decides what is built and in what order, which is not the question in front of them.",
   "Correct. The request is for a decision; the need is for a way to decide. Surfacing what would settle it — impact, cost, whether it endangers the Sprint Goal — leaves the decision where it belongs and leaves the team better able to make the next one without her.",
   "Defers a decision that must be made this Sprint to an event that happens after it ends."
  ],
  "hard": "A is what the team asked for and looks like responsiveness. B invokes a real accountability that does not extend to this decision."
 },
 {
  "n": 20,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management",
  "shape": "Choose a different stance",
  "type": "single",
  "stem": "A bicycle manufacturer's Product Owner states the Product Goal as delivering the connected-bike platform by the end of the financial year. Asked how it helps him choose between two competing Product Backlog items, he says both are part of the platform so both are needed.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Accept it; the Product Goal is the Product Owner's to define.",
   "Suggest he attach measurable success criteria to the existing goal.",
   "Help the Product Owner see that a goal which cannot settle an ordering question is not doing the work a Product Goal exists to do, and work with him toward one that describes a future state rather than a delivery date.",
   "Propose a Product Goal himself, as a worked example for the Product Owner to learn from."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "Correct that the Product Goal belongs to the Product Owner — and helping him find effective techniques for Product Backlog management is explicitly the Scrum Master's service to him. Accepting a goal that cannot arbitrate is not respect for the accountability; it is declining to serve it.",
   "Criteria attached to a delivery date measure whether the date was met. The weakness is not that the goal is unmeasured; it is that it describes output rather than a changed state.",
   "Correct. The test of a Product Goal is whether it can settle an argument about order. A date is not an objective, and a goal that includes everything in the platform excludes nothing.",
   "Supplies the answer rather than the capability, and makes the Scrum Master's judgement the reference point for a decision that is not his."
  ],
  "hard": "B is a real improvement addressed to the wrong weakness, which makes it the most attractive wrong answer in the set."
 },
 {
  "n": 21,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "Two stakeholder groups at a regional airport want opposite things from the same feature: operations wants fewer steps for staff, and the regulator's liaison wants an additional confirmation at every step. Both have escalated to the Product Owner, who asks the Scrum Master for help.",
  "ask": "What is the most appropriate help to offer?",
  "options": [
   "Suggest the Developers build both variants and let the Sprint Review settle it.",
   "Advise the Product Owner that the regulatory requirement takes precedence, so the decision is already made.",
   "Recommend the Product Owner escalate to the airport's executive team for a ruling.",
   "Facilitate a session with both groups and the Product Owner in which the underlying interests are surfaced, so that her decision is made with the conflict in the open rather than in two separate conversations."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "Builds two solutions to avoid one conversation, and uses the Sprint Review as a decision-making forum rather than as an inspection of a Done Increment.",
   "May well be true, and it is not the Scrum Master's call. It also assumes the regulatory position is accurately represented by the liaison, which is one of the things a joint session would test.",
   "Removes the decision from the person accountable for value and hands it to people further from the product and the users.",
   "Correct. Facilitation is precisely the service asked for, and the decision remains the Product Owner's. Two groups negotiating through an intermediary produce positions; the same groups in a room with their interests visible usually produce options neither had brought."
  ],
  "hard": "B sounds decisive and expert. It resolves the conflict by taking the Product Owner's decision on her behalf, which is the failure the item is built around."
 },
 {
  "n": 22,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management",
  "shape": "Restore an accountability",
  "type": "tf",
  "stem": "Consider the following statement.",
  "ask": "A Product Owner may be a committee, provided one of its members is designated to communicate the committee's decisions to the Developers.",
  "options": [
   "True",
   "False"
  ],
  "correct": [
   1
  ],
  "rationale": [
   "",
   "Correct — the statement is false. The Product Owner is one person, not a committee. A committee may represent its interests through the Product Owner, and anyone wanting the Product Backlog reordered must do so by convincing the Product Owner — but accountability for maximising value cannot be split across a group. The designated communicator the statement describes is a proxy: someone relaying decisions made by people who are not accountable and are not in the room, which is exactly the arrangement a single-person accountability exists to prevent."
  ],
  "hard": "The statement offers a mechanism that appears to solve the practical problem — a single point of contact — while leaving the accountability diffused, which is the actual failure."
 },
 {
  "n": 23,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Managing Technical Risk · Done",
  "shape": "Force a decision",
  "type": "single",
  "stem": "A mobile network operator's team keeps a list of items labelled post-launch. It holds a known memory leak, an unencrypted internal interface, and two performance defects, and it has grown for five Sprints. The Product Owner has seen the list and says it will be dealt with after the launch in eight weeks.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Establish which items mean the Increment does not meet the Definition of Done, and separate those from the ones that are genuinely ordering decisions.",
   "Accept the decision; the Product Owner is accountable for ordering the work.",
   "Escalate the security item to whoever owns information security at the operator.",
   "Order the security item into the Product Backlog, since an unencrypted interface is not a matter of preference."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. The list is doing two different jobs at once. Work failing the Definition of Done is not Done and no ordering decision changes that; genuine technical debt competes on value like everything else. Separating the two is what makes the Product Owner's decision a real one.",
   "Treats every item on the list as a prioritisation question. Some may be. Anything the Definition of Done requires is not, and accepting the list wholesale means work has been reported as Done that was not.",
   "May well follow, and going outside the Scrum Team before establishing what the item actually is skips the step that would say whether this is a Definition of Done breach or a deferred improvement.",
   "Takes the ordering decision. Even where the Scrum Master is right about the severity, the accountability is not theirs to exercise."
  ],
  "hard": "D and C are both reasonable responses to a genuine security concern, and both act before the diagnosis. Lists labelled post-launch routinely conceal two different categories of item."
 },
 {
  "n": 24,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Product Backlog Management · Stakeholders",
  "shape": "Force a decision",
  "type": "multi",
  "stem": "The Product Owner at a pension fund holds the accountability for three products across three Scrum Teams. She attends Sprint Planning for all three and is otherwise largely unreachable; backlogs go unrefined for weeks. She says she is doing her best and that the organisation will not appoint anyone else.",
  "ask": "Which TWO actions are most appropriate?",
  "options": [
   "Have the Scrum Master hold one of the three Product Backlogs so she can concentrate on the other two.",
   "Make the cost of her unavailability visible — decisions waiting, rework, items entering Sprints unrefined — to the people who decide how the role is staffed.",
   "Ask the Developers to make the product decisions she is not available to make.",
   "Help her separate the activities that genuinely require the accountability from those she has absorbed and could delegate."
  ],
  "correct": [
   1,
   3
  ],
  "rationale": [
   "The accountability boundary crossed, however pragmatically. It also conceals the shortfall by covering it, which guarantees the staffing decision is never revisited.",
   "Correct. This is an organisational capacity problem rather than a coaching one, and the people who decide staffing are currently deciding without knowing what it costs. Evidence in their terms is what turns that into a real decision.",
   "Moves value decisions to people who do not hold the accountability. It also removes the visible pain, which is the thing most likely to produce a change.",
   "Correct. Product Owners routinely absorb work that does not require the accountability — writing every item, attending every meeting, answering every question directly. Separating what only she can do from what she has taken on is often worth more than an extra person."
  ],
  "hard": "A is the most tempting because it solves the immediate problem using the person best placed to help. It is the same error as C committed by a more senior actor."
 },
 {
  "n": 25,
  "bucket": "Product, Stakeholder, and Technical-Risk Support",
  "focus": "Stakeholders & Customers · Events",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "At a national archive, stakeholders attend every Sprint Review and give detailed feedback. The Product Owner thanks them and records it, and the Product Backlog is unchanged afterwards. Attendance has begun to fall.",
  "ask": "What is the most appropriate action for the Scrum Master?",
  "options": [
   "Ask the Product Owner to open each Sprint Review by saying what she did with the previous Sprint's feedback, including what she decided against and why.",
   "Ask stakeholders to submit feedback in writing so it can be tracked through to a decision.",
   "Add each piece of feedback to the Product Backlog as an item, so it is visibly captured.",
   "Reduce the frequency of Sprint Reviews so there is more to show at each one."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Attendance is falling because the event has stopped affecting anything, which is a failure of adaptation rather than of inspection. Closing the loop visibly — including the decisions to decline — is what makes the next Sprint Review worth attending, and it leaves the ordering decision with the Product Owner.",
   "A tracking mechanism for feedback that is already being recorded. The problem is not that it is lost but that nothing changes as a result.",
   "Turns every remark into a backlog item, inflating the Product Backlog while still telling nobody what was decided. Being captured is not the same as being acted on, or declined.",
   "Fewer opportunities to inspect and adapt, offered in response to a problem caused by not adapting."
  ],
  "hard": "C looks like responsiveness and is how most teams answer this. It is the same behaviour that is already failing, with more paperwork attached."
 },
 {
  "n": 26,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "A director at an industrial pump manufacturer asks the Scrum Master to supply each team's velocity monthly, so that the eight teams can be compared and the weakest given support. He is sincere about the support.",
  "ask": "What is the most appropriate response?",
  "options": [
   "Supply the figures with a written caveat setting out their limitations.",
   "Supply the figures; transparency is a Scrum value and refusing looks defensive.",
   "Refuse, and explain that velocity is not a productivity measure and cannot be compared across teams.",
   "Explain why comparing velocity across teams produces the opposite of what he wants, and offer measures that would actually reveal which teams need support."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "A caveat that will not survive the first slide the numbers appear on. Once comparative figures exist, they get compared.",
   "Transparency concerns the real state of the work, not the supply of any number requested. A measure certain to be misread does not create transparency; it creates a confident wrong picture.",
   "Correct on the substance and it offers nothing. The director has a real problem — he cannot tell which teams need help — and a refusal leaves him holding it, which usually means he finds another number that is worse.",
   "Correct. Both halves are needed: why the measure will mislead, and what would answer the question he actually has. Teams inflate estimates the moment velocity is compared, so the measure degrades as soon as it is used this way."
  ],
  "hard": "C is right about velocity and fails the person asking. A is the most common real-world compromise and among the least effective."
 },
 {
  "n": 27,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture · Events",
  "shape": "Restore an accountability",
  "type": "single",
  "stem": "A department manager at a ferry operator has begun attending every Daily Scrum. He does not speak, but the Developers have started addressing their updates to him and the event has become a report of individual progress. He says he attends because it is the most efficient way to stay informed.",
  "ask": "What is the most appropriate action?",
  "options": [
   "Address the manager's actual need — staying informed — with something that does not require his presence, and help the Developers reclaim the event.",
   "Explain to the Developers that they should be addressing one another rather than the manager.",
   "Allow it; the Daily Scrum is not a private event and he is not interfering.",
   "Ask the manager to stop attending, since the Daily Scrum is for the Developers."
  ],
  "correct": [
   0
  ],
  "rationale": [
   "Correct. Both halves again: the manager has a legitimate need and no good way to meet it, and the Developers have lost their event. Solving the first is what makes the second hold.",
   "Asks the Developers to behave differently while the cause of the behaviour remains in the room. People address the most senior person present; that is not a habit anyone can be talked out of.",
   "Technically accurate about attendance and blind to what has happened. The event has stopped being a re-planning session and become a status report, which is the anti-pattern itself.",
   "Removes the symptom and leaves the need. He will find another route to the information, and the next one may be worse than a manager sitting quietly at the back."
  ],
  "hard": "C cites something true — others may attend — and D is the answer most Scrum Masters give. Both treat the presence rather than the reason for it."
 },
 {
  "n": 28,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "single",
  "stem": "A biotechnology company has adopted Scrum while keeping a governance process that requires design authority sign-off before development begins and release board approval afterwards. Teams Sprint between the two gates. Lead time from idea to production is unchanged since the adoption.",
  "ask": "What is the most appropriate first step for the Scrum Master?",
  "options": [
   "Propose removing both gates, since they prevent the empirical loop from operating.",
   "Ask the design authority to approve items quarterly rather than individually.",
   "Measure and make visible where the time between idea and production is actually spent, so the organisation can see what the gates cost and decide.",
   "Accept the gates as a constraint of a regulated industry and optimise the work between them."
  ],
  "correct": [
   2
  ],
  "rationale": [
   "The right diagnosis proposed as an opening move, to an organisation that adopted these gates for reasons nobody has yet examined. It will be refused, and the refusal makes the next conversation harder.",
   "A sensible-sounding accommodation that may reduce the delay while leaving the gate — and the ignorance about its cost — in place.",
   "Correct. Nobody currently knows what the gates cost, which is why an unchanged lead time has prompted nothing. Evidence about where time goes is cheap to gather, hard to argue with, and is what makes any later conversation about the gates possible.",
   "Accepts as a regulatory constraint something that has not been shown to be one. Some controls in a biotechnology company are law; a design authority sign-off before development usually is not."
  ],
  "hard": "D attracts because regulated industry is a phrase that ends inquiries. The item turns on separating a genuine constraint from an established habit, in a setting where both genuinely exist."
 },
 {
  "n": 29,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Make transparent, facilitate",
  "type": "multi",
  "stem": "At a cinema chain, database changes are made only by a central data team that serves eleven Scrum Teams and works to its own two-week queue.",
  "ask": "Which of the following are likely consequences? Select all that apply.",
  "options": [
   "Forecasting becomes less reliable, because a dependency outside the team determines completion.",
   "The Definition of Done is likely to be quietly weakened for work touching the database.",
   "Scrum Teams cannot reliably produce a Done Increment within a Sprint.",
   "The central data team should be represented in each Scrum Team's Sprint Planning."
  ],
  "correct": [
   0,
   1,
   2
  ],
  "rationale": [
   "Correct. A forecast rests on what the team controls. Where a two-week external queue determines completion, the team's own estimates stop predicting anything.",
   "Correct. Teams under pressure to show progress define Done in terms they can actually reach, which usually means database work is marked complete before it has been made.",
   "Correct. Where completion depends on another group's queue, an Increment cannot reliably be finished inside the Sprint — which is the condition everything else in the framework rests on.",
   "Incorrect. This is a proposed remedy rather than a consequence, and a weak one: attending Sprint Planning does not remove the queue, and treating a structural dependency as a communication problem is the misdiagnosis that keeps it in place."
  ],
  "hard": "D is a reasonable-sounding action placed among consequences. Select-all items frequently mix categories, and reading the question rather than the options is what catches it."
 },
 {
  "n": 30,
  "bucket": "Evolving the Agile Organization",
  "focus": "Organizational Design & Culture",
  "shape": "Sequence correctly",
  "type": "single",
  "stem": "Leaders at a container shipping line describe the organisation as agile. Scrum Teams exist and the events run. Every decision of consequence — team composition, tooling, whether an Increment may be released — is still taken by a director. The teams have stopped proposing things.",
  "ask": "What is the most appropriate approach for the Scrum Master?",
  "options": [
   "Accept that culture change of this kind is beyond a Scrum Master's reach, and concentrate on what happens inside the Sprint.",
   "Raise with the leadership group that their behaviour contradicts what they say about the organisation.",
   "Coach the teams to make decisions and present them as decided, rather than asking permission.",
   "Identify one decision currently escalated that a team could demonstrably make well, agree with the relevant director that the team will make it, and use the result as evidence."
  ],
  "correct": [
   3
  ],
  "rationale": [
   "The horizon judgement applied too pessimistically. Reward systems and funding models may be out of reach; a single delegated decision is not.",
   "Accurate, confrontational, and unlikely to change anything. Told that their behaviour contradicts their words, the cheapest available response for leaders is to dispute the description.",
   "Asks the teams to take a risk on the Scrum Master's behalf, in an organisation that has taught them not to. The first team to try will be corrected, and the lesson will travel faster than any coaching.",
   "Correct. Decision authority moves in specific instances rather than in principle, and one demonstrated success is worth more than an argument about culture. Choosing a decision the team will visibly make well is the whole craft of it."
  ],
  "hard": "B is true and C sounds like it builds self-management. Both mistake a statement about the organisation for a change in it."
 }
];
