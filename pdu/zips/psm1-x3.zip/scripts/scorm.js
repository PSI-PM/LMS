/* SCORM 1.2 API wrapper
   Finds the LMS API adapter, and degrades gracefully to standalone mode
   (no LMS present) so the exam still runs when opened directly. */
var SCORM = (function () {
  var api = null,
      initialized = false,
      available = false,
      startTime = new Date();

  function findAPI(win) {
    var tries = 0;
    while (win.API == null && win.parent != null && win.parent != win && tries < 500) {
      tries++;
      win = win.parent;
    }
    return win.API;
  }

  function getAPI() {
    var a = null;
    try {
      if (window.parent && window.parent != window) a = findAPI(window.parent);
      if (!a && window.top && window.top.opener) a = findAPI(window.top.opener);
      if (!a) a = findAPI(window);
    } catch (e) { a = null; }
    return a;
  }

  function init() {
    api = getAPI();
    if (!api) {
      available = false;
      log('No SCORM API found - running in standalone mode.');
      return false;
    }
    var ok = api.LMSInitialize('');
    initialized = (ok === 'true' || ok === true);
    available = initialized;
    if (initialized) {
      set('cmi.core.lesson_status', 'incomplete');
      set('cmi.core.score.min', '0');
      set('cmi.core.score.max', '100');
      commit();
    }
    return initialized;
  }

  function set(key, value) {
    if (!available || !api) return false;
    try {
      var r = api.LMSSetValue(key, String(value));
      return (r === 'true' || r === true);
    } catch (e) { return false; }
  }

  function get(key) {
    if (!available || !api) return '';
    try { return api.LMSGetValue(key); } catch (e) { return ''; }
  }

  function commit() {
    if (!available || !api) return false;
    try { return api.LMSCommit('') === 'true'; } catch (e) { return false; }
  }

  function finish() {
    if (!available || !api) return false;
    try {
      setSessionTime();
      api.LMSCommit('');
      var r = api.LMSFinish('');
      initialized = false;
      return (r === 'true' || r === true);
    } catch (e) { return false; }
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function setSessionTime() {
    var ms = new Date() - startTime;
    var s = Math.floor(ms / 1000);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var sec = s % 60;
    set('cmi.core.session_time', pad(h) + ':' + pad(m) + ':' + pad(sec));
  }

  /* Record a single interaction (best-effort; not all LMSs store these) */
  function recordInteraction(index, id, type, learnerResponse, correct) {
    if (!available) return;
    var p = 'cmi.interactions.' + index + '.';
    set(p + 'id', id);
    set(p + 'type', type);
    set(p + 'student_response', learnerResponse);
    set(p + 'result', correct ? 'correct' : 'wrong');
    set(p + 'time', timeStamp());
  }

  function timeStamp() {
    var d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function log(msg) {
    if (window.console && console.log) console.log('[SCORM] ' + msg);
  }

  return {
    init: init,
    set: set,
    get: get,
    commit: commit,
    finish: finish,
    recordInteraction: recordInteraction,
    isAvailable: function () { return available; }
  };
})();
